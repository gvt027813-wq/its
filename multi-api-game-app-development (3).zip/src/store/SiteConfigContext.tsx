import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { DEFAULT_SITE_CONFIG, normalizeSiteConfig, type PublicSiteConfig } from "../config/siteConfig";
import { fbOnValue } from "../services/firebase";

interface SiteConfigValue {
  config: PublicSiteConfig;
  loadingConfig: boolean;
}

const SiteConfigContext = createContext<SiteConfigValue | null>(null);

export function SiteConfigProvider({ children }: { children: ReactNode }) {
  const [config, setConfig] = useState<PublicSiteConfig>(DEFAULT_SITE_CONFIG);
  const [loadingConfig, setLoadingConfig] = useState(true);

  useEffect(() => {
    // This is public, read-only configuration. Only the separate admin portal can write it.
    return fbOnValue("siteConfig/public", (value) => {
      setConfig(normalizeSiteConfig(value));
      setLoadingConfig(false);
    });
  }, []);

  const value = useMemo(() => ({ config, loadingConfig }), [config, loadingConfig]);
  return <SiteConfigContext.Provider value={value}>{children}</SiteConfigContext.Provider>;
}

export function useSiteConfig() {
  const context = useContext(SiteConfigContext);
  if (!context) throw new Error("useSiteConfig must be used within SiteConfigProvider");
  return context;
}