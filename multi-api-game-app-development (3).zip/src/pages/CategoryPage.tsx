import { useMemo, useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { useGames } from "../store/GameContext";
import GameGrid from "../components/ui/GameGrid";
import PageShell from "../components/ui/PageShell";
import { SkeletonGrid, Btn } from "../components/ui/Common";
import { CATEGORIES } from "../data/categories";
import AdUnit from "../components/AdUnit";
import SEO from "../components/SEO";
import { categoryIntro, categorySchema } from "../utils/categorySeo";
import { categoryPath } from "../utils/gameUrl";

export default function CategoryPage() {
  const { id = "all" } = useParams();
  const { games, loading } = useGames();
  const [visible, setVisible] = useState(48);
  const info = CATEGORIES.find((c) => c.id === id);

  useEffect(() => setVisible(48), [id]);

  const list = useMemo(() => games.filter((g) => g.category === id), [games, id]);

  return (
    <PageShell title={info?.name || "Category"} subtitle={`${list.length} games in this category`} icon={info?.icon || "🎮"} maxWidth="max-w-none">
      {info && <SEO
        title={`Free ${info.name} Games Online`}
        description={`${categoryIntro(info)} Play free ${info.name.toLowerCase()} games online with no download required.`}
        keywords={`${info.name.toLowerCase()} games, free ${info.name.toLowerCase()} games online, browser ${info.name.toLowerCase()} games`}
        path={categoryPath(info.id)}
        structuredData={categorySchema(info, list.length)}
      />}
      {info && <section className="mb-6 max-w-3xl"><h2 className="text-xl font-bold text-white">Free {info.name} Games</h2><p className="mt-2 text-sm leading-relaxed text-slate-400">{categoryIntro(info)} Browse the collection below, save favorites, and return whenever you want a quick game.</p></section>}
      <AdUnit variant="leaderboard" className="mb-6 mt-0" slotId="category-top" />
      {loading ? (
        <SkeletonGrid count={24} />
      ) : (
        <>
          <GameGrid games={list.slice(0, visible)} emptyText="No games in this category yet." />
          {visible < list.length && (
            <div className="mt-8 flex justify-center">
              <Btn onClick={() => setVisible((v) => v + 48)}>Load More</Btn>
            </div>
          )}
        </>
      )}
    </PageShell>
  );
}
