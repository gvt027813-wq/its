const { getAdmin } = require('../lib/firebaseAdmin');

const config = {
  brandName: 'Play VAULT', brandAccent: 'VAULT', founderName: 'Vivek Trivedi', supportEmail: 'vivektrivedi236@gmail.com', heroBadge: 'Play VAULT',
  heroPrimary: { label: 'Browse Games', url: '/games' }, heroSecondary: { label: 'Surprise Me', url: '/random' }, footerLinks: [], customNavLinks: [], socialLinks: [],
  ads: { enabled: true, leaderboardKey: '3663e208db547fc2fc1193e3a6afba7e', bannerKey: 'f797eccf5010d58dccbf709e921e996c', popupEnabled: true, popupDelaySeconds: 45, popupFrequencyMinutes: 3, maxInFeedAds: 4, disabledSlots: {} },
};

getAdmin().database().ref('siteConfig/public').set(config).then(() => console.log('Public site configuration seeded.')).catch((error) => { console.error(error.message); process.exit(1); });