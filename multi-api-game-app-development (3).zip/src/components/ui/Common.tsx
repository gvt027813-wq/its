import { motion } from "framer-motion";
import type { ReactNode } from "react";

export function Loader({ label = "Loading games…" }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-24">
      <div className="h-12 w-12 animate-spin rounded-full border-4 border-slate-700 border-t-indigo-500" />
      <p className="text-sm text-slate-400">{label}</p>
    </div>
  );
}

export function SkeletonGrid({ count = 24 }: { count?: number }) {
  return (
    <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-7 xl:grid-cols-8">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="aspect-square animate-pulse rounded-2xl bg-slate-800/60" />
      ))}
    </div>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl bg-slate-800/60 p-5 ring-1 ring-white/5 ${className}`}>{children}</div>
  );
}

export function Prose({ children }: { children: ReactNode }) {
  return <div className="space-y-4 text-sm leading-relaxed text-slate-300">{children}</div>;
}

export function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mb-6">
      <h2 className="mb-2 text-lg font-bold text-white">{title}</h2>
      <div className="space-y-3 text-sm leading-relaxed text-slate-300">{children}</div>
    </div>
  );
}

export function Badge({ children, color = "bg-indigo-500/20 text-indigo-300" }: { children: ReactNode; color?: string }) {
  return <span className={`rounded-md px-2 py-0.5 text-xs font-semibold ${color}`}>{children}</span>;
}

export function Btn({
  children,
  onClick,
  variant = "primary",
  type = "button",
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "outline";
  type?: "button" | "submit";
  className?: string;
}) {
  const styles = {
    primary: "bg-indigo-600 text-white hover:bg-indigo-500",
    ghost: "bg-slate-800 text-slate-200 hover:bg-slate-700",
    outline: "border border-white/15 text-slate-200 hover:bg-slate-800",
  };
  return (
    <button type={type} onClick={onClick} className={`rounded-xl px-5 py-2.5 text-sm font-bold transition ${styles[variant]} ${className}`}>
      {children}
    </button>
  );
}

export function Accordion({ items }: { items: { q: string; a: string }[] }) {
  return (
    <div className="space-y-3">
      {items.map((it, i) => (
        <details key={i} className="group rounded-xl bg-slate-800/60 ring-1 ring-white/5">
          <summary className="flex cursor-pointer items-center justify-between px-4 py-3 text-sm font-semibold text-white">
            {it.q}
            <span className="text-indigo-400 transition-transform group-open:rotate-45">+</span>
          </summary>
          <p className="px-4 pb-4 text-sm text-slate-400">{it.a}</p>
        </details>
      ))}
    </div>
  );
}

export function StatCard({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <motion.div whileHover={{ y: -3 }} className="rounded-2xl bg-slate-800/60 p-4 text-center ring-1 ring-white/5">
      <div className="text-2xl">{icon}</div>
      <div className="mt-1 text-lg font-extrabold text-white">{value}</div>
      <div className="text-xs text-slate-400">{label}</div>
    </motion.div>
  );
}
