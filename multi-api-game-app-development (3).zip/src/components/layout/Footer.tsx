import { Link } from "react-router-dom";
import { useSiteConfig } from "../../store/SiteConfigContext";

const COLS = [
  { title: "Discover Games", links: [["Home", "/"], ["All Games", "/games"], ["Trending", "/trending"], ["New Games", "/new"], ["Top Rated", "/top-rated"]] },
  { title: "Categories", links: [["Action Games", "/games/action"], ["Puzzle Games", "/games/puzzle"], ["Racing Games", "/games/racing"], ["Sports Games", "/games/sports"], ["Arcade Games", "/games/arcade"]] },
  { title: "Account & Perks", links: [["Profile", "/profile"], ["Wallet", "/wallet"], ["Rewards", "/rewards"], ["Go Premium", "/premium"], ["Settings", "/settings"]] },
  { title: "Support & Help", links: [["Help Center", "/help"], ["FAQ", "/faq"], ["Feedback", "/feedback"], ["Partners", "/partners"], ["Sitemap", "/sitemap"]] },
  { title: "Legal & Policy", links: [["Privacy", "/privacy"], ["Terms", "/terms"], ["Cookies", "/cookies"], ["DMCA", "/dmca"], ["Disclaimer", "/disclaimer"]] },
];

export default function Footer() {
  const { config } = useSiteConfig();
  return (
    <footer className="mt-16 border-t border-amber-500/20 bg-slate-950/80 backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 md:grid-cols-5">
          {COLS.map((c) => (
            <div key={c.title}>
              <h4 className="mb-3 font-display text-sm font-bold uppercase tracking-wider text-amber-400">{c.title}</h4>
              <ul className="space-y-2">
                {c.links.map(([label, to]) => (
                  <li key={to}>
                    <Link to={to} className="text-xs text-slate-400 transition-colors hover:text-white">{label}</Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {config.footerLinks.length > 0 && (
          <div className="mt-10 flex flex-wrap justify-center gap-x-6 gap-y-2 border-t border-white/10 pt-6">
            {config.footerLinks.map((item) => (
              <a key={`${item.label}-${item.url}`} href={item.url} target={item.url.startsWith("http") ? "_blank" : undefined} rel="noreferrer" className="text-xs font-semibold text-slate-400 hover:text-amber-300">
                {item.label}
              </a>
            ))}
          </div>
        )}

        <div className="mt-10 flex flex-col items-center justify-between gap-6 border-t border-amber-500/20 pt-8 sm:flex-row">
          <div className="flex items-center gap-3">
            <img src="/images/logo.png" alt="VaultPlays Play VAULT" className="h-10 w-10 rounded-xl ring-1 ring-amber-400/40 shadow-lg" />
            <div>
              <span className="font-display text-lg font-black tracking-wide text-white">
                VAULT<span className="text-amber-400">PLAYS</span>
              </span>
              <p className="text-[11px] font-semibold text-slate-400">Play VAULT · 1000+ Free Online Games</p>
            </div>
          </div>

          <div className="text-center text-xs text-slate-400 sm:text-right">
            <p>© 2026 <strong className="text-white">VaultPlays (Play VAULT)</strong> · Owned & Founded by <strong className="text-amber-300">Vivek Trivedi</strong></p>
            <p className="mt-1 text-slate-500">📧 {config.supportEmail} · Play 1000+ free games online with zero download required.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
