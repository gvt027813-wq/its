/** Run only in a trusted server shell with FIREBASE_SERVICE_ACCOUNT configured. */
const { getAdmin } = require('../lib/firebaseAdmin');
const email = process.argv[2];
if (!email) throw new Error('Usage: node backend/scripts/setAdminClaim.js <owner-email>');

(async () => {
  const admin = getAdmin();
  const user = await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid, { admin: true });
  console.log(`Admin claim set for ${email}. Sign out and sign in again to refresh the token.`);
})().catch((error) => { console.error(error.message); process.exit(1); });