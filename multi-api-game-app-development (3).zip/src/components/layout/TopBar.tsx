import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useGames } from "../../store/GameContext";

import { gamePath } from "../../utils/gameUrl";

export default function TopBar({ onMenu }: { onMenu: () => void }) {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const { search, favorites } = useGames();
  const navigate = useNavigate();
  const boxRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const results = q.trim() ? search(q).slice(0, 8) : [];

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        inputRef.current?.focus();
        setOpen(true);
      }
    };
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onClick);
      document.removeEventListener("keydown", onKey);
    };
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (q.trim()) {
      navigate(`/search?q=${encodeURIComponent(q.trim())}`);
      setOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 border-b border-amber-500/20 bg-slate-950/90 backdrop-blur-xl shadow-lg shadow-black/40">
      <div className="flex h-16 items-center gap-3 px-3 sm:px-5">
        <button
          onClick={onMenu}
          className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-300 transition hover:bg-slate-800 hover:text-white lg:hidden"
          aria-label="Open Navigation Menu"
        >
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        <Link to="/" className="group flex items-center gap-3">
          <div className="relative">
            <img
              src="/images/logo.png"
              alt="VaultPlays Play VAULT"
              className="h-10 w-10 rounded-xl shadow-md ring-1 ring-amber-400/40 transition-transform duration-300 group-hover:scale-105"
            />
            <div className="absolute -inset-0.5 rounded-xl bg-amber-400/20 opacity-0 blur transition group-hover:opacity-100" />
          </div>
          <div className="leading-none">
            <div className="flex items-center gap-1.5">
              <span className="font-display text-lg font-black tracking-wide text-white">
                VAULT<span className="text-amber-400">PLAYS</span>
              </span>
              <span className="hidden rounded bg-amber-400/15 px-1.5 py-0.5 text-[9px] font-bold text-amber-300 ring-1 ring-amber-400/30 sm:inline-block">
                PRO
              </span>
            </div>
            <p className="mt-0.5 hidden text-[10px] font-semibold text-slate-400 sm:block">
              Play VAULT · 1000+ Free Online Games
            </p>
          </div>
        </Link>

        <div ref={boxRef} className="relative mx-2 flex-1 max-w-xl">
          <form onSubmit={submit}>
            <svg className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.3-4.3" />
            </svg>
            <input
              ref={inputRef}
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setOpen(true);
              }}
              onFocus={() => setOpen(true)}
              placeholder="Search 1000+ games (e.g. Moto X3M, 2048, Racing)..."
              className="w-full rounded-xl border border-white/10 bg-slate-900/90 py-2.5 pl-10 pr-16 text-sm text-white placeholder-slate-500 outline-none transition focus:border-amber-400/60 focus:ring-2 focus:ring-amber-400/20"
            />
            <div className="pointer-events-none absolute right-3 top-1/2 hidden -translate-y-1/2 items-center gap-1 text-[10px] font-bold text-slate-500 sm:flex">
              <kbd className="rounded bg-slate-800 px-1.5 py-0.5 border border-white/10">Ctrl</kbd>
              <span>+</span>
              <kbd className="rounded bg-slate-800 px-1.5 py-0.5 border border-white/10">K</kbd>
            </div>
          </form>
          {open && results.length > 0 && (
            <div className="absolute left-0 right-0 top-full z-50 mt-2 overflow-hidden rounded-2xl border border-amber-500/20 bg-slate-900/95 p-1 shadow-2xl backdrop-blur-xl">
              <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">Search Results</div>
              {results.map((g) => (
                <Link
                  key={g.id}
                  to={gamePath(g)}
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-3 rounded-xl px-3 py-2 transition hover:bg-slate-800/80"
                >
                  <img src={g.thumb} alt={g.title} className="h-10 w-10 rounded-lg object-cover ring-1 ring-white/10" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold text-white">{g.title}</p>
                    <p className="text-xs capitalize text-amber-400/80">🗂️ {g.category} · ★ {g.rating?.toFixed(1)}</p>
                  </div>
                  <span className="rounded-lg bg-amber-500/10 px-2 py-1 text-[10px] font-bold text-amber-300">Play</span>
                </Link>
              ))}
            </div>
          )}
        </div>

        <Link
          to="/favorites"
          className="relative flex h-10 items-center gap-2 rounded-xl bg-slate-800/80 px-3.5 text-sm font-bold text-slate-200 ring-1 ring-white/10 transition hover:bg-slate-700 hover:text-white"
        >
          <svg className="h-4 w-4 fill-rose-500 text-rose-500" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z" />
          </svg>
          <span className="hidden sm:inline">Favorites</span>
          {favorites.length > 0 && (
            <span className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-gradient-to-r from-rose-500 to-pink-600 px-1 text-[10px] font-extrabold text-white shadow">
              {favorites.length}
            </span>
          )}
        </Link>

        <Link
          to="/profile"
          className="hidden h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-sm font-black text-slate-950 shadow-md ring-2 ring-amber-300/30 transition hover:scale-105 sm:flex"
          aria-label="User Profile"
        >
          VT
        </Link>
      </div>
    </header>
  );
}
