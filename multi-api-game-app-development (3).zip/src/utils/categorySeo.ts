import type { CategoryInfo } from "../types";
import { absoluteUrl } from "./seoConfig";
import { categoryPath } from "./gameUrl";

const CATEGORY_INTROS: Record<string, string> = {
  action: "Explore fast-paced action games with quick challenges, responsive controls, and instant browser play.",
  puzzle: "Discover puzzle games that reward logic, pattern spotting, planning, and a little patience.",
  racing: "Start a free racing game in your browser and take on tracks, time trials, stunts, and speed challenges.",
  sports: "Play sports games online, from football and basketball to golf, pool, and skill-based challenges.",
  arcade: "Enjoy classic arcade-style games built for quick sessions, repeat runs, and high-score chases.",
  shooting: "Browse browser shooting games with skill-based missions, targets, and action challenges.",
  adventure: "Find adventure games with exploration, quests, stories, and new worlds to discover.",
  strategy: "Choose strategy games that reward thoughtful decisions, planning, and smart resource management.",
  board: "Play board and card-inspired games in your browser, including timeless tactical favorites.",
  casual: "Relax with casual browser games designed for quick, easy-to-start sessions.",
  io: "Jump into multiplayer-inspired .io games with quick matches and competitive browser gameplay.",
};

export function categoryIntro(category?: CategoryInfo) {
  if (!category) return "Browse free browser games across every category and start playing without a download.";
  return CATEGORY_INTROS[category.id] || `Browse free ${category.name.toLowerCase()} games and play instantly in your browser.`;
}

export function categorySchema(category: CategoryInfo, count: number) {
  const path = categoryPath(category.id);
  return {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: `Free ${category.name} Games`,
    description: categoryIntro(category),
    url: absoluteUrl(path),
    numberOfItems: count,
    isPartOf: { "@type": "WebSite", name: "Play VAULT", url: absoluteUrl("/") },
  };
}