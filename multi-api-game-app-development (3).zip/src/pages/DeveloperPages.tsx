import PageShell from "../components/ui/PageShell";
import { Card, Btn, Section } from "../components/ui/Common";

export function Partners() {
  const partners = ["GamePix", "Arkadium", "GameDistribution", "Poki", "CrazyGames", "Y8"];
  return (
    <PageShell title="Our Partners" subtitle="Powered by the best in the industry" icon="🤝" maxWidth="max-w-3xl">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {partners.map((p) => (
          <Card key={p} className="flex h-24 items-center justify-center text-lg font-bold text-slate-300">{p}</Card>
        ))}
      </div>
    </PageShell>
  );
}

export function Advertise() {
  return (
    <PageShell title="Advertise With Us" subtitle="Reach millions of engaged gamers" icon="📢" maxWidth="max-w-3xl">
      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        <Card className="text-center"><p className="text-2xl font-black text-white">2M+</p><p className="text-xs text-slate-400">Monthly players</p></Card>
        <Card className="text-center"><p className="text-2xl font-black text-white">15min</p><p className="text-xs text-slate-400">Avg. session</p></Card>
        <Card className="text-center"><p className="text-2xl font-black text-white">60%</p><p className="text-xs text-slate-400">Return rate</p></Card>
      </div>
      <Section title="Ad Formats">
        <p>Display banners, video pre-roll, rewarded ads, and sponsored game placements. Custom packages available.</p>
      </Section>
      <Btn>Request Media Kit</Btn>
    </PageShell>
  );
}
