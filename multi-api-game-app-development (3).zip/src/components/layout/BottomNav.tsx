import { NavLink } from "react-router-dom";
import { cn } from "../../utils/cn";

const ITEMS = [
  { to: "/", label: "Home", icon: "🏠", end: true },
  { to: "/games", label: "Games", icon: "🎮" },
  { to: "/trending", label: "Trending", icon: "🔥" },
  { to: "/favorites", label: "Faves", icon: "❤️" },
  { to: "/profile", label: "Me", icon: "👤" },
];

export default function BottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-white/10 bg-slate-900/95 backdrop-blur-lg lg:hidden">
      <div className="flex items-center justify-around">
        {ITEMS.map((it) => (
          <NavLink
            key={it.to}
            to={it.to}
            end={it.end}
            className={({ isActive }) =>
              cn(
                "flex flex-1 flex-col items-center gap-0.5 py-2 text-[10px] font-medium transition",
                isActive ? "text-indigo-400" : "text-slate-400"
              )
            }
          >
            <span className="text-lg">{it.icon}</span>
            {it.label}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
