import { createContext, useContext, useEffect, useMemo, useState, useCallback, type ReactNode } from "react";
import type { Game } from "../types";
import { loadGames } from "../services/gameApi";
import { ensureVisitorSession, fbSet, fbGet, fbPush, onFirebaseUser } from "../services/firebase";

const FAV_KEY = "playvault:favorites";
const RECENT_KEY = "playvault:recent";
const RECENT_MAX = 20;

interface GameContextValue {
  games: Game[];
  loading: boolean;
  favorites: string[];
  recent: string[];
  toggleFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  addRecent: (id: string) => void;
  getGame: (id: string) => Game | undefined;
  byCategory: (cat: string) => Game[];
  search: (q: string) => Game[];
}

const GameContext = createContext<GameContextValue | null>(null);

function readLS(key: string): string[] {
  try {
    return JSON.parse(localStorage.getItem(key) || "[]");
  } catch {
    return [];
  }
}

export function GameProvider({ children }: { children: ReactNode }) {
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [favorites, setFavorites] = useState<string[]>(() => readLS(FAV_KEY));
  const [recent, setRecent] = useState<string[]>(() => readLS(RECENT_KEY));
  const [userId, setUserId] = useState<string | null>(null);

  // Load game catalog
  useEffect(() => {
    loadGames().then((g) => {
      setGames(g);
      setLoading(false);
    });
  }, []);

  // Uses an authenticated Firebase UID, not a spoofable localStorage identifier.
  useEffect(() => {
    ensureVisitorSession().then(setUserId);
    return onFirebaseUser(setUserId);
  }, []);

  // Hydrate from Firebase cloud only once a secure identity is available.
  useEffect(() => {
    if (!userId) return;
    fbGet<{ favorites?: string[]; recent?: string[] }>(`users/${userId}`).then((remote) => {
      if (!remote) return;
      if (remote.favorites?.length && readLS(FAV_KEY).length === 0) setFavorites(remote.favorites);
      if (remote.recent?.length && readLS(RECENT_KEY).length === 0) setRecent(remote.recent);
    });
  }, [userId]);

  // Persist locally + to Firebase Realtime DB
  useEffect(() => {
    localStorage.setItem(FAV_KEY, JSON.stringify(favorites));
    if (userId) fbSet(`users/${userId}/favorites`, favorites);
  }, [favorites, userId]);

  useEffect(() => {
    localStorage.setItem(RECENT_KEY, JSON.stringify(recent));
    if (userId) fbSet(`users/${userId}/recent`, recent);
  }, [recent, userId]);

  const toggleFavorite = useCallback((id: string) => {
    setFavorites((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  }, []);
  const isFavorite = useCallback((id: string) => favorites.includes(id), [favorites]);

  const addRecent = useCallback((id: string) => {
    setRecent((p) => [id, ...p.filter((x) => x !== id)].slice(0, RECENT_MAX));
    // Per-user, append-only cloud play stat. Source popularity stays separate.
    if (userId) fbPush(`stats/plays/${userId}`, { gameId: id, createdAt: Date.now() });
  }, [userId]);

  const getGame = useCallback((id: string) => games.find((g) => g.id.toLowerCase() === id.toLowerCase()), [games]);
  const byCategory = useCallback(
    (cat: string) => {
      if (cat === "all") return games;
      if (cat === "featured") return games.filter((g) => g.featured);
      return games.filter((g) => g.category === cat);
    },
    [games]
  );
  const search = useCallback(
    (q: string) => {
      const s = q.trim().toLowerCase();
      if (!s) return [];
      return games.filter(
        (g) => g.title.toLowerCase().includes(s) || g.category.includes(s) || g.description.toLowerCase().includes(s)
      );
    },
    [games]
  );

  const value = useMemo(
    () => ({ games, loading, favorites, recent, toggleFavorite, isFavorite, addRecent, getGame, byCategory, search }),
    [games, loading, favorites, recent, toggleFavorite, isFavorite, addRecent, getGame, byCategory, search]
  );

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGames() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error("useGames must be used within GameProvider");
  return ctx;
}
