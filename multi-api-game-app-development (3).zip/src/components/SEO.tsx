import { useEffect } from "react";
import { absoluteUrl, buildPageMeta, SEO_CONFIG, websiteSchema } from "../utils/seoConfig";

type JsonLd = Record<string, unknown>;

interface Props {
  title?: string;
  description?: string;
  keywords?: string;
  path?: string;
  image?: string;
  type?: "website" | "article" | "video.other";
  noIndex?: boolean;
  structuredData?: JsonLd | JsonLd[];
}

function upsertMeta(attribute: "name" | "property", key: string, content: string) {
  let element = document.head.querySelector(`meta[${attribute}="${key}"]`) as HTMLMetaElement | null;
  if (!element) {
    element = document.createElement("meta");
    element.setAttribute(attribute, key);
    document.head.appendChild(element);
  }
  element.content = content;
}

function upsertLink(rel: string, href: string) {
  let element = document.head.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement | null;
  if (!element) {
    element = document.createElement("link");
    element.rel = rel;
    document.head.appendChild(element);
  }
  element.href = href;
}

/** Writes one complete, crawlable metadata record into document.head. */
export default function SEO({ title, description, keywords, path = "/", image, type = "website", noIndex = false, structuredData }: Props) {
  useEffect(() => {
    const meta = buildPageMeta(title, description);
    const canonical = absoluteUrl(path);
    const socialImage = absoluteUrl(image || SEO_CONFIG.defaultImage);
    const graph = [websiteSchema(), ...(structuredData ? (Array.isArray(structuredData) ? structuredData : [structuredData]) : [])];

    document.title = meta.title;
    upsertMeta("name", "description", meta.description);
    upsertMeta("name", "keywords", keywords || meta.keywords);
    upsertMeta("name", "author", SEO_CONFIG.owner);
    upsertMeta("name", "robots", noIndex ? "noindex,follow" : "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1");
    upsertMeta("property", "og:type", type);
    upsertMeta("property", "og:title", meta.title);
    upsertMeta("property", "og:description", meta.description);
    upsertMeta("property", "og:url", canonical);
    upsertMeta("property", "og:site_name", SEO_CONFIG.siteName);
    upsertMeta("property", "og:image", socialImage);
    upsertMeta("property", "og:image:alt", `${SEO_CONFIG.siteName} online games`);
    upsertMeta("name", "twitter:card", "summary_large_image");
    upsertMeta("name", "twitter:site", SEO_CONFIG.twitterHandle);
    upsertMeta("name", "twitter:title", meta.title);
    upsertMeta("name", "twitter:description", meta.description);
    upsertMeta("name", "twitter:image", socialImage);
    upsertLink("canonical", canonical);

    let jsonScript = document.head.querySelector("script[data-playvault-schema]") as HTMLScriptElement | null;
    if (!jsonScript) {
      jsonScript = document.createElement("script");
      jsonScript.type = "application/ld+json";
      jsonScript.dataset.playvaultSchema = "true";
      document.head.appendChild(jsonScript);
    }
    jsonScript.textContent = JSON.stringify({ "@context": "https://schema.org", "@graph": graph });
  }, [description, image, keywords, noIndex, path, structuredData, title, type]);

  return null;
}