import { useState } from "react";
import { Link } from "react-router-dom";
import type { Game } from "../types";
import { cn } from "../utils/cn";
import { gamePath } from "../utils/gameUrl";

interface Props {
  game: Game;
  onPlay: (game: Game) => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
}

function gradientFor(title: string) {
  const grads = [
    "from-violet-600 to-indigo-700",
    "from-rose-600 to-pink-700",
    "from-emerald-600 to-teal-700",
    "from-blue-600 to-cyan-700",
    "from-amber-500 to-orange-700",
    "from-fuchsia-600 to-purple-700",
  ];
  let h = 0;
  for (let i = 0; i < title.length; i++) h = (h * 31 + title.charCodeAt(i)) & 0xffff;
  return grads[h % grads.length];
}

export default function GameCard({ game, onPlay, isFavorite, onToggleFavorite }: Props) {
  const [err, setErr] = useState(false);

  return (
    <div className="group relative overflow-hidden rounded-2xl bg-slate-800/60 ring-1 ring-white/5 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-indigo-900/40 hover:ring-indigo-400/40">
      <Link to={gamePath(game)} onClick={() => onPlay(game)} aria-label={`Play ${game.title}`} className="relative block aspect-square overflow-hidden">
        {!err && game.thumb ? (
          <img
            src={game.thumb}
            alt={`Play ${game.title} online`}
            loading="lazy"
            decoding="async"
            width={480}
            height={480}
            onError={() => setErr(true)}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        ) : (
          <div className={cn("flex h-full w-full items-center justify-center bg-gradient-to-br", gradientFor(game.title))}>
            <span className="px-3 text-center text-lg font-bold text-white/90">{game.title}</span>
          </div>
        )}

        {/* overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/10 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

        {/* play button */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-all duration-300 group-hover:opacity-100">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white/95 shadow-xl transition-transform group-hover:scale-110">
            <svg className="ml-1 h-6 w-6 text-indigo-700" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </div>

        {game.featured && (
          <span className="absolute left-2 top-2 rounded-md bg-gradient-to-r from-amber-400 to-orange-500 px-2 py-0.5 text-[10px] font-bold text-white shadow">
            ⭐ HOT
          </span>
        )}

      </Link>

      <div className="absolute right-2 top-2">

        <button
          onClick={() => onToggleFavorite(game.id)}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-900/60 backdrop-blur transition-colors hover:bg-slate-900/90"
          aria-label={isFavorite ? `Remove ${game.title} from favorites` : `Save ${game.title} to favorites`}
        >
          <svg className={cn("h-4 w-4 transition-colors", isFavorite ? "fill-rose-500 text-rose-500" : "fill-none text-white")} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z" />
          </svg>
        </button>
      </div>

      <div className="p-2.5">
        <h3 className="truncate text-sm font-semibold text-white"><Link to={gamePath(game)} onClick={() => onPlay(game)} className="hover:text-amber-300">{game.title}</Link></h3>
        <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <span className="text-amber-400">★</span>
            {game.rating?.toFixed(1)}
          </span>
          <span className="capitalize">{game.category}</span>
        </div>
      </div>
    </div>
  );
}
