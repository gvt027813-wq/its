import type { Game } from "../types";
import { normalizeCategory } from "./categories";

// Curated real, embeddable HTML5 games (open/free sources).
// These guarantee content even if remote feeds are unavailable.
interface Raw {
  t: string;
  c: string;
  u: string;
  img: string;
  d?: string;
}

const RAW: Raw[] = [
  { t: "2048", c: "puzzle", u: "https://play2048.co/", img: "https://play2048.co/meta/apple-touch-icon.png", d: "Join the numbers and get to the 2048 tile!" },
  { t: "Hextris", c: "puzzle", u: "https://hextris.io/", img: "https://hextris.io/images/logo.png", d: "Fast paced puzzle game inspired by Tetris." },
  { t: "Pacman", c: "arcade", u: "https://freepacman.org/", img: "https://freepacman.org/pacman-logo.png", d: "Classic Pacman arcade game." },
  { t: "Tetris", c: "puzzle", u: "https://tetris.com/play-tetris", img: "https://tetris.com/build/_assets/logo-tetris-DE7NBFOB.svg", d: "The legendary block-stacking puzzle game." },
  { t: "Chess", c: "board", u: "https://lichess.org/", img: "https://lichess1.org/assets/logo/lichess-favicon-256.png", d: "Play chess online against players worldwide." },
  { t: "Sudoku", c: "puzzle", u: "https://sudoku.com/", img: "https://sudoku.com/img/social/sudoku.png", d: "Number placement logic puzzle." },
  { t: "Wordle", c: "puzzle", u: "https://www.nytimes.com/games/wordle/index.html", img: "https://www.nytimes.com/games-assets/v2/assets/wordle/Wordle-App-Icon.png", d: "Guess the five letter word." },
  { t: "Slither Snake", c: "io", u: "https://slither.io/", img: "https://slither.io/s/faveicon32.png", d: "Grow your snake, dominate the arena." },
  { t: "Agar Battle", c: "io", u: "https://agar.io/", img: "https://agar.io/img/favicon-32x32.png", d: "Eat cells, grow bigger, survive." },
  { t: "Krunker FPS", c: "shooting", u: "https://krunker.io/", img: "https://krunker.io/img/favicon.png", d: "Fast paced browser first person shooter." },
];

export const FALLBACK_GAMES: Game[] = RAW.map((r, i) => ({
  id: `local-${i}`,
  title: r.t,
  description: r.d || "Play now for free!",
  category: normalizeCategory(r.c),
  thumb: r.img,
  url: r.u,
  source: "Curated",
  featured: i < 4,
  rating: 4 + Math.round(Math.random() * 10) / 10,
  plays: 10000 + Math.floor(Math.random() * 990000),
}));
