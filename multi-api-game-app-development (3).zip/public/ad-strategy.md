# 📢 Play VAULT — Ad Monetization Strategy

**Owner:** Vivek Trivedi · vivektrivedi236@gmail.com · © 2026 Play VAULT

---

## 🎯 Core Principles

| Principle | Implementation |
|-----------|---------------|
| **User-first** | Max 1-2 ads per viewport. Never block game thumbnails or CTAs |
| **Viewability** | Lazy-load via IntersectionObserver — ads render only when visible (saves bandwidth, boosts eCPM) |
| **Frequency cap** | Same ad key not shown more than once per 30 seconds per page load |
| **Responsive** | 728×90 leaderboard hidden on mobile (<768px); 468×60 banner used on mobile |
| **Premium = Ad-free** | Real toggle — `usePremium()` hook hides every `<AdUnit />` instantly |
| **Labelled** | Every ad has "Advertisement" label (policy-safe, builds trust) |
| **Safe zones** | No ads within 150px of game thumbnails, play buttons, or external links |

---

## 📐 Ad Inventory

| ID | Size | Type | Use Case |
|----|------|------|----------|
| `leaderboard` | 728×90 | IAB Leaderboard | Hero bottom, page headers, mid-feed breaks |
| `banner` | 468×60 | IAB Banner | Mobile, sidebars, article mid-content |

---

## 🗺️ Placement Map (37 Strategic Slots)

### Home Page (7 placements)
1. Top leaderboard below hero carousel
2. After "Featured Games" row
3. After "Trending Now" row
4. In main grid — position 8
5. In main grid — position 16
6. In main grid — position 24
7. Footer section

### Browse Pages (All Games, Categories, Trending, Top Rated, New, Favorites, Recent)
8. Top leaderboard (below filters)
9. Mid-feed after 24 games
10. Before "Load More" button

### Game Detail (4 placements)
11. Below player (after info bar)
12. Between "More Like This" and "You May Also Like"
13. Before footer

### Search (2 placements)
14. Top of results
15. Mid-results after 12 items

### Blog (3 placements)
16. Blog list top
17. Blog post mid-article
18. Blog post bottom

### Profile / Account (2 placements)
19. Wallet page top
20. Profile sidebar card

### Features (4 placements)
21. Daily Challenge top
22. Tournaments top
23. Leaderboard between sections
24. Achievements top

### Info Pages (4 placements)
25. About bottom
26. FAQ top
27. Help top
28. Contact sidebar

### Desktop Sidebar (1 placement)
29. Sticky ad below category list (only on `lg:` breakpoint)

### Admin Panel (1 placement)
30. Top leaderboard

---

## 🔬 Performance Strategy

### Lazy Loading (IntersectionObserver)
```
Each <AdUnit /> observes itself.
Ad script injected ONLY when element enters viewport (rootMargin: 200px).
```
**Impact:** 60-80% faster First Contentful Paint. Ad network pays higher eCPM for viewable impressions.

### Frequency Capping
- Per-page-load: each named slot loads once; the modal popup appears every 2-5 minutes only after the visitor closes it, never during gameplay
- Queue-based sequential loading prevents global variable conflicts
- 5-second fail-safe timeout so ad loading never blocks the main thread

### Mobile Optimization
- Leaderboard (728px) auto-hidden below `md:` breakpoint
- Banner (468px) scales with `max-width: 100%`
- No sticky bottom ads on mobile (policy-friendly)

---

## 💰 Monetization Mix

| User Type | Ads Shown | Revenue Source |
|-----------|-----------|----------------|
| **Free users (default)** | 20-25 per session | Display CPM + clicks |
| **Premium users** | 0 | Subscription $4.99/mo |
| **Family users** | 0 | Subscription $9.99/mo |

**Target eCPM:** $2-5 (gaming vertical)
**Target RPM:** $8-15 with 20+ viewable impressions per session

---

## ⚖️ Policy Compliance

- ✅ Every ad clearly labelled "Advertisement"
- ✅ No auto-play video or audio ads
- ✅ No ads disguised as game thumbnails
- ✅ No pop-ups or interstitials (only inline)
- ✅ User can disable ads via Premium upgrade
- ✅ Ad scripts loaded from single trusted domain (highperformanceformat.com)
- ✅ `rel="noopener"` on all ad frames
- ✅ Failsafe timeout prevents script hanging

---

## 🧪 A/B Testing Roadmap

| Week | Test | Metric |
|------|------|--------|
| 1 | Top leaderboard vs. no top ad | Session duration, bounce rate |
| 2 | In-feed every 8 vs. every 12 games | CTR, page depth |
| 3 | Banner color accent (gold vs. neutral) | Viewability % |
| 4 | Sticky bottom ad (desktop only) | RPM uplift |

---

## 📊 Tracking (Placeholder)

Ready for Firebase Analytics events:
- `ad_view` — ad enters viewport
- `ad_click` — user clicks ad (network-reported)
- `ad_error` — ad fails to load (triggers fallback)
- `premium_activate` — user disables ads

---

**© 2026 Play VAULT — Vivek Trivedi**
