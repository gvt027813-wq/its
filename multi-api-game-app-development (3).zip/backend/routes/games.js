const { z } = require('zod');
const Game = require('../models/Game');

const CATEGORIES = ['action', 'puzzle', 'racing', 'sports', 'arcade', 'shooting', 'adventure', 'girls', 'strategy', 'board', 'casual', 'io'];
const httpsUrl = z.string().url().refine((value) => value.startsWith('https://'), 'Only HTTPS URLs are accepted');
const gameInput = z.object({
  title: z.string().trim().min(3).max(120), description: z.string().trim().min(10).max(2000).optional().default(''), category: z.enum(CATEGORIES),
  thumb: httpsUrl.optional(), banner: httpsUrl.optional(), url: httpsUrl,
  width: z.number().int().min(100).max(4096).optional(), height: z.number().int().min(100).max(4096).optional(),
});
const clamp = (value, min, max, fallback) => { const parsed = Number.parseInt(String(value), 10); return Number.isFinite(parsed) ? Math.min(max, Math.max(min, parsed)) : fallback; };

exports.getGames = async (req, res) => {
  const limit = clamp(req.query.limit, 1, 100, 24), page = clamp(req.query.page, 1, 1000, 1), filter = { verified: true };
  const category = String(req.query.category || ''), q = String(req.query.q || '').trim();
  if (CATEGORIES.includes(category)) filter.category = category;
  if (req.query.featured === 'true') filter.featured = true;
  if (q.length >= 2 && q.length <= 80) filter.$text = { $search: q };
  try {
    const [games, total] = await Promise.all([
      Game.find(filter).sort(q ? { score: { $meta: 'textScore' }, plays: -1 } : { plays: -1, createdAt: -1 }).skip((page - 1) * limit).limit(limit).lean(),
      Game.countDocuments(filter),
    ]);
    res.json({ status: 'success', data: games, meta: { total, page, limit, pages: Math.ceil(total / limit) } });
  } catch (error) { console.error('games.list', req.requestId, error); res.status(500).json({ error: 'Unable to load games', requestId: req.requestId }); }
};

exports.addGame = async (req, res) => {
  const parsed = gameInput.safeParse(req.body);
  if (!parsed.success) return res.status(422).json({ error: 'Invalid game data', fields: parsed.error.flatten().fieldErrors, requestId: req.requestId });
  try {
    const game = await Game.create({ ...parsed.data, source: 'Developer Submission', submittedBy: req.user.uid, verified: false, featured: false });
    res.status(201).json({ status: 'success', message: 'Game submitted for review', data: game });
  } catch (error) { console.error('games.create', req.requestId, error); res.status(500).json({ error: 'Unable to submit game', requestId: req.requestId }); }
};

exports.verifyGame = async (req, res) => {
  const id = String(req.params.id || '');
  if (!/^[a-f\d]{24}$/i.test(id)) return res.status(400).json({ error: 'Invalid game id', requestId: req.requestId });
  try {
    const game = await Game.findByIdAndUpdate(id, { verified: true, verifiedAt: new Date(), verifiedBy: req.user.email || req.user.uid }, { new: true, runValidators: true });
    if (!game) return res.status(404).json({ error: 'Game not found', requestId: req.requestId });
    res.json({ status: 'success', message: 'Game verified', data: game });
  } catch (error) { console.error('games.verify', req.requestId, error); res.status(500).json({ error: 'Unable to verify game', requestId: req.requestId }); }
};