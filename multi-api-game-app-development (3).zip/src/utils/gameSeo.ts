import type { Game } from "../types";
import { absoluteUrl } from "./seoConfig";
import { categoryPath, gamePath } from "./gameUrl";

const CATEGORY_COPY: Record<string, { intro: string; controls: string; tips: string[] }> = {
  action: { intro: "fast-paced action", controls: "Use your keyboard, mouse, or touch controls to move, react quickly, and complete each challenge.", tips: ["Watch enemy patterns before committing to a move.", "Use short sessions to learn the controls before chasing a high score."] },
  puzzle: { intro: "brain-teasing puzzle", controls: "Use your mouse or touch screen to select, arrange, match, and solve the board.", tips: ["Look for repeatable patterns before making a move.", "Slow down when a level introduces a new mechanic."] },
  racing: { intro: "high-speed racing", controls: "Use arrow keys, WASD, or touch controls to steer, accelerate, brake, and keep your line.", tips: ["Brake before tight turns instead of during them.", "Learn the track layout before pushing for the fastest time."] },
  sports: { intro: "competitive sports", controls: "Use your mouse, keyboard, or touch controls to aim, time your moves, and outscore opponents.", tips: ["Prioritize timing over speed when making a shot.", "Practice one game mode until the controls feel natural."] },
  arcade: { intro: "classic arcade", controls: "Use your keyboard, mouse, or touch screen to start playing instantly.", tips: ["Focus on staying alive before chasing bonus points.", "Short, repeated runs are the fastest way to improve."] },
};

function copyFor(game: Game) {
  return CATEGORY_COPY[game.category] || {
    intro: "free browser game",
    controls: "Use your mouse, keyboard, or touch screen to play directly in your browser.",
    tips: ["Take a moment to learn the controls before your first serious run.", "Try different strategies to find what works best for you."],
  };
}

export function gameDescription(game: Game) {
  const copy = copyFor(game);
  return `Play ${game.title}, a free ${copy.intro} on Play VAULT. No download is required: start in your browser and return anytime to improve your score.`;
}

export function gameFaq(game: Game) {
  const copy = copyFor(game);
  return [
    { question: `Is ${game.title} free to play?`, answer: `Yes. ${game.title} is available to play for free on Play VAULT in a compatible web browser.` },
    { question: `How do I play ${game.title}?`, answer: copy.controls },
    { question: `Do I need to download ${game.title}?`, answer: `No download or install is required. Open the game page and select Play to start in your browser.` },
  ];
}

export function gameGuide(game: Game) {
  const copy = copyFor(game);
  return {
    controls: copy.controls,
    tips: copy.tips,
    features: ["Instant browser play with no download", `Free ${game.category} gameplay`, "Works with mouse, keyboard, or touch when supported"],
  };
}

export function gameSchemas(game: Game) {
  const path = gamePath(game);
  const faq = gameFaq(game);
  return [
    {
      "@context": "https://schema.org",
      "@type": "VideoGame",
      name: game.title,
      description: gameDescription(game),
      url: absoluteUrl(path),
      image: absoluteUrl(game.thumb),
      genre: game.category,
      gamePlatform: "Web browser",
      applicationCategory: "Game",
      operatingSystem: "Any",
      isAccessibleForFree: true,
      publisher: { "@type": "Organization", name: "Play VAULT" },
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faq.map((item) => ({
        "@type": "Question",
        name: item.question,
        acceptedAnswer: { "@type": "Answer", text: item.answer },
      })),
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: absoluteUrl("/") },
        { "@type": "ListItem", position: 2, name: `${game.category} games`, item: absoluteUrl(categoryPath(game.category)) },
        { "@type": "ListItem", position: 3, name: game.title, item: absoluteUrl(path) },
      ],
    },
  ];
}