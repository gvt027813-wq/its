import { useMemo } from "react";
import { useGames } from "../store/GameContext";
import HeroCarousel from "../components/HeroCarousel";
import GameRow from "../components/ui/GameRow";
import GameGrid from "../components/ui/GameGrid";
import { SkeletonGrid, StatCard } from "../components/ui/Common";
import { CATEGORIES } from "../data/categories";
import { useNavigate, Link } from "react-router-dom";
import SEO from "../components/SEO";
import AdUnit from "../components/AdUnit";
import { categoryPath, gamePath } from "../utils/gameUrl";

export default function Home() {
  const { games, loading, recent, getGame } = useGames();
  const navigate = useNavigate();

  const featured = useMemo(() => games.filter((g) => g.featured).slice(0, 20), [games]);
  const topRated = useMemo(() => [...games].sort((a, b) => (b.rating || 0) - (a.rating || 0)).slice(0, 20), [games]);
  const trending = useMemo(() => [...games].sort((a, b) => (b.plays || 0) - (a.plays || 0)).slice(0, 20), [games]);
  const recentGames = useMemo(() => recent.map(getGame).filter(Boolean).slice(0, 12) as typeof games, [recent, getGame]);

  const catRows = CATEGORIES.filter((c) => c.id !== "all" && c.id !== "featured").slice(0, 6);

  const playRandom = () => {
    if (games.length) navigate(gamePath(games[Math.floor(Math.random() * games.length)]));
  };

  return (
    <div>
      <SEO
        title="Free Online Games — Play 1000+ Games"
        description="Play free online games instantly on VaultPlays (Play VAULT / Vault Play). Discover 1000+ action, arcade, puzzle, racing and casual games with no download required."
        keywords="VaultPlays, Play VAULT, Vault Play, Play Vault, VaultPlay, Vault Games, free online games, browser games, free games no download, HTML5 games"
      />

      <div className="mb-6">
        <HeroCarousel onPlayRandom={playRandom} featured={featured[0]} onPlayFeatured={(g) => navigate(gamePath(g))} />
      </div>

      <div className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon="🎮" label="Games" value={loading ? "…" : `${games.length.toLocaleString()}+`} />
        <StatCard icon="🗂️" label="Categories" value={`${CATEGORIES.length - 2}`} />
        <StatCard icon="⚡" label="Instant Play" value="No Install" />
        <StatCard icon="💯" label="Price" value="100% Free" />
      </div>

      <AdUnit variant="leaderboard" slotId="home-top" />

      {loading ? (
        <SkeletonGrid />
      ) : (
        <>
          {recentGames.length > 0 && <GameRow title="Recently Played" icon="🕒" games={recentGames} seeAllTo="/recent" />}
          <GameRow title="Featured Games" icon="⭐" games={featured} seeAllTo="/games" />
          <AdUnit variant="banner" slotId="home-featured-break" />
          <GameRow title="Trending Now" icon="🔥" games={trending} seeAllTo="/trending" />
          <GameRow title="Top Rated" icon="🏆" games={topRated} seeAllTo="/top-rated" />

          {catRows.map((c) => (
            <GameRow key={c.id} title={c.name} icon={c.icon} games={games.filter((g) => g.category === c.id).slice(0, 14)} seeAllTo={categoryPath(c.id)} />
          ))}

          <section className="mt-10">
            <h2 className="mb-4 text-xl font-extrabold text-white sm:text-2xl">🎯 Discover More Free Games</h2>
            <GameGrid games={games.slice(0, 40)} />
          </section>

          {/* SEO Content Section for High Search Ranking */}
          <section className="mt-16 rounded-3xl border border-amber-500/20 bg-slate-900/60 p-6 sm:p-8 backdrop-blur-xl">
            <div className="max-w-4xl space-y-4">
              <h2 className="font-display text-2xl font-black text-white sm:text-3xl">
                VaultPlays (Play VAULT) — Play 1000+ Free Online Browser Games
              </h2>
              <p className="text-sm leading-relaxed text-slate-300">
                Welcome to <strong>VaultPlays</strong> (also known as <strong>Play VAULT</strong>, <strong>Vault Play</strong>, <strong>Play Vault</strong>, or <strong>VaultPlay</strong>), the ultimate free online gaming destination. Founded by <strong>Vivek Trivedi</strong>, VaultPlays brings you a curated library of over 1,000 free HTML5 browser games that you can play instantly on your desktop, tablet, or mobile phone without downloading or installing any apps.
              </p>

              <h3 className="font-display text-lg font-bold text-amber-300">
                Why Play Games on VaultPlays (Play VAULT)?
              </h3>
              <ul className="grid gap-2 text-sm text-slate-300 sm:grid-cols-2">
                <li className="flex items-center gap-2"><span className="text-amber-400">✓</span> 100% Free with zero downloads required</li>
                <li className="flex items-center gap-2"><span className="text-amber-400">✓</span> Fast-loading HTML5 games for mobile & PC</li>
                <li className="flex items-center gap-2"><span className="text-amber-400">✓</span> Save favorite games & track play history</li>
                <li className="flex items-center gap-2"><span className="text-amber-400">✓</span> New games added weekly across 12+ categories</li>
              </ul>

              <h3 className="font-display text-lg font-bold text-amber-300">
                Popular Game Categories on VaultPlays
              </h3>
              <div className="flex flex-wrap gap-2 pt-1">
                {CATEGORIES.filter((c) => c.id !== "all" && c.id !== "featured").map((c) => (
                  <Link
                    key={c.id}
                    to={categoryPath(c.id)}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-slate-800/80 px-3 py-1.5 text-xs font-semibold text-slate-200 transition hover:border-amber-400/50 hover:text-amber-300"
                  >
                    <span>{c.icon}</span> Free {c.name} Games
                  </Link>
                ))}
              </div>
            </div>
          </section>
        </>
      )}
    </div>
  );
}
