import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import AdUnit from "./AdUnit";
import { usePremium } from "../hooks/usePremium";
import { useSiteConfig } from "../store/SiteConfigContext";

const STORAGE_KEY = "playvault:last-ad-popup";

/**
 * A labelled, dismissible in-site interstitial. It never appears while a game
 * is being played, has a clear close action and respects a configurable cap.
 * It does not invoke browser popups or redirect visitors.
 */
export default function AdPopup() {
  const { pathname } = useLocation();
  const { premium } = usePremium();
  const { config } = useSiteConfig();
  const [open, setOpen] = useState(false);
  const [scheduleCycle, setScheduleCycle] = useState(0);

  useEffect(() => {
    const isGamePlayerRoute = pathname.split("/").filter(Boolean).length >= 3 && pathname.startsWith("/games/");
    if (premium || !config.ads.enabled || !config.ads.popupEnabled || isGamePlayerRoute) return;
    const last = Number(localStorage.getItem(STORAGE_KEY) || 0);
    const gap = config.ads.popupFrequencyMinutes * 60 * 1000;
    // First display uses the admin-configured delay. Later displays respect the
    // 2-5 minute cap from the most recent dismissal.
    const delay = last ? Math.max(0, last + gap - Date.now()) : config.ads.popupDelaySeconds * 1000;
    const timer = window.setTimeout(() => setOpen(true), delay);
    return () => window.clearTimeout(timer);
  }, [config.ads, pathname, premium, scheduleCycle]);

  const close = () => {
    localStorage.setItem(STORAGE_KEY, String(Date.now()));
    setOpen(false);
    setScheduleCycle((cycle) => cycle + 1);
  };

  if (!open || premium) return null;
  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center bg-slate-950/70 p-4 backdrop-blur-sm sm:items-center" role="dialog" aria-modal="true" aria-label="Sponsored message">
      <div className="relative w-full max-w-xl rounded-2xl border border-amber-400/30 bg-slate-900 p-5 shadow-2xl">
        <button onClick={close} className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-sm text-slate-200 hover:bg-slate-700" aria-label="Close advertisement">✕</button>
        <p className="mb-2 pr-8 text-xs font-semibold uppercase tracking-[0.18em] text-amber-300">Sponsored message</p>
        <p className="mb-3 text-sm text-slate-300">Ads help keep Play VAULT free. You can dismiss this message or upgrade for ad-free play.</p>
        <AdUnit variant="banner" className="my-0" hideLabel responsive={false} slotId="consent-popup" />
        <div className="mt-4 flex justify-end"><button onClick={close} className="rounded-lg bg-slate-800 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700">Continue to Play VAULT</button></div>
      </div>
    </div>
  );
}