import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import PageShell from "../components/ui/PageShell";
import { Card, Btn, Section, Accordion, StatCard } from "../components/ui/Common";
import { ArticleAd } from "../components/AdPlacements";
import AdUnit from "../components/AdUnit";
import SEO from "../components/SEO";
import { breadcrumbSchema } from "../utils/seoConfig";

export function About() {
  return (
    <PageShell title="About Play VAULT" icon="ℹ️" maxWidth="max-w-3xl">
      <SEO title="About Play VAULT" description="Learn about Play VAULT, a free browser gaming hub founded by Vivek Trivedi." path="/about" />
      <div className="mb-6 overflow-hidden rounded-3xl">
        <img src="/images/hero.jpg" alt="" className="h-48 w-full object-cover" />
      </div>
      <div className="mb-6 grid grid-cols-3 gap-3">
        <StatCard icon="🎮" label="Games" value="1000+" />
        <StatCard icon="🌍" label="Players" value="2M+" />
        <StatCard icon="⭐" label="Rating" value="4.8" />
      </div>

      <div className="mb-6 flex flex-col items-center gap-4 rounded-3xl bg-gradient-to-br from-amber-500/20 via-slate-800/60 to-slate-800/60 p-6 ring-1 ring-amber-400/25 sm:flex-row">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-amber-600 font-display text-2xl font-black text-slate-950 ring-4 ring-amber-300/30">
          VT
        </div>
        <div className="text-center sm:text-left">
          <h3 className="font-display text-xl font-extrabold text-white">Vivek Trivedi</h3>
          <p className="text-sm font-semibold text-amber-300">Founder, Owner & Copyright Holder — Play VAULT</p>
          <p className="mt-1 text-sm text-slate-400">📧 vivektrivedi236@gmail.com</p>
        </div>
      </div>

      <Section title="Our Mission">
        <p>Play VAULT is the ultimate all-in-one gaming hub founded by Vivek Trivedi, bringing you over 1,000 free HTML5 games from top providers — all playable instantly in your browser with no downloads or installs.</p>
      </Section>
      <Section title="Why Play VAULT?">
        <p>We aggregate the best games across action, puzzle, racing, sports, and dozens more categories into a single, beautifully designed app. Save favorites, earn rewards, compete on leaderboards, and discover new games every day.</p>
      </Section>
      <Section title="Powered By">
        <p>Games are sourced from GamePix and other trusted open feeds. All rights belong to their respective creators. We simply make them easy to find and fun to play.</p>
      </Section>
      <ArticleAd />
    </PageShell>
  );
}

export function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <PageShell title="Contact Us" subtitle="We'd love to hear from you" icon="✉️" maxWidth="max-w-xl">
      <SEO title="Contact Play VAULT" description="Contact Play VAULT for support, business questions, and copyright enquiries." path="/contact" />
      <div className="mb-4 grid grid-cols-2 gap-3">
        <Card className="text-center"><div className="text-2xl">📧</div><p className="mt-1 text-sm font-semibold text-white">Email</p><p className="text-xs text-slate-400">vivektrivedi236@gmail.com</p></Card>
        <Card className="text-center"><div className="text-2xl">💬</div><p className="mt-1 text-sm font-semibold text-white">Live Chat</p><p className="text-xs text-slate-400">24/7 support</p></Card>
      </div>
      {sent ? (
        <Card className="text-center"><div className="text-5xl">✅</div><p className="mt-2 font-bold text-white">Message sent!</p><p className="text-slate-400">We'll reply within 24 hours.</p></Card>
      ) : (
        <Card>
          <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="space-y-3">
            <input placeholder="Your name" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
            <input placeholder="Your email" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
            <textarea rows={5} placeholder="Message…" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
            <Btn type="submit" className="w-full">Send Message</Btn>
          </form>
        </Card>
      )}
    </PageShell>
  );
}

const FAQ_ITEMS = [
  { q: "Are the games really free?", a: "Yes! All 1000+ games on Play VAULT are 100% free to play. No downloads, no hidden fees." },
  { q: "Do I need to create an account?", a: "No account is needed to play. But signing up lets you save favorites, earn coins, and track achievements." },
  { q: "Can I play on mobile?", a: "Absolutely. Play VAULT is fully responsive and works great on phones, tablets, and desktops." },
  { q: "How do I save my favorite games?", a: "Just tap the heart icon on any game. Your favorites are saved on your device." },
  { q: "What are coins used for?", a: "Earn coins by playing daily and completing challenges. Redeem them for avatars, badges, and premium perks." },
  { q: "How do I remove ads?", a: "Upgrade to Play VAULT Premium for an ad-free experience plus exclusive games and bonus coins." },
];

export function FAQ() {
  return (
    <PageShell title="Frequently Asked Questions" icon="❓" maxWidth="max-w-2xl">
      <SEO title="Play VAULT FAQ" description="Answers about free online games, browser play, favorites, mobile support, and Play VAULT Premium." path="/faq" structuredData={{ "@context": "https://schema.org", "@type": "FAQPage", mainEntity: FAQ_ITEMS.map((item) => ({ "@type": "Question", name: item.q, acceptedAnswer: { "@type": "Answer", text: item.a } })) }} />
      <AdUnit variant="leaderboard" className="mb-6 mt-0" />
      <Accordion items={FAQ_ITEMS} />
      <ArticleAd />
      <p className="mt-6 text-center text-sm text-slate-400">Still need help? <Link to="/contact" className="text-indigo-400 hover:underline">Contact us</Link></p>
    </PageShell>
  );
}

export function Help() {
  return <HelpInner />;
}

function HelpInner() {
  const topics = [
    { i: "🎮", t: "Getting Started", d: "How to play your first game", to: "/onboarding" },
    { i: "❤️", t: "Favorites & History", d: "Saving and finding games", to: "/favorites" },
    { i: "💰", t: "Coins & Rewards", d: "Earning and spending coins", to: "/wallet" },
    { i: "👑", t: "Premium", d: "Membership benefits", to: "/premium" },
    { i: "⚙️", t: "Account Settings", d: "Manage your profile", to: "/settings" },
    { i: "❓", t: "FAQ", d: "Common questions", to: "/faq" },
  ];
  return (
    <PageShell title="Help Center" subtitle="Find answers and guides" icon="🆘" maxWidth="max-w-3xl">
      <AdUnit variant="leaderboard" className="mb-4 mt-0" />
      <div className="grid gap-3 sm:grid-cols-2">
        {topics.map((t) => (
          <Link key={t.t} to={t.to}><Card className="flex items-center gap-3 transition hover:ring-indigo-500/40"><span className="text-3xl">{t.i}</span><div><p className="font-bold text-white">{t.t}</p><p className="text-xs text-slate-400">{t.d}</p></div></Card></Link>
        ))}
      </div>
      <ArticleAd />
    </PageShell>
  );
}

export const BLOG_POSTS = [
  { slug: "top-10-games-2026", title: "Top 10 Free Games to Play in 2026", excerpt: "Our editors pick the must-play browser games this year.", date: "Jan 15, 2026", img: "/images/promo1.jpg", cat: "Guides" },
  { slug: "puzzle-games-brain", title: "How Puzzle Games Boost Your Brain", excerpt: "The science behind why puzzle games are great for you.", date: "Jan 10, 2026", img: "/images/promo2.jpg", cat: "Wellness" },
  { slug: "io-games-explained", title: ".io Games Explained: The Multiplayer Revolution", excerpt: "Everything you need to know about the .io genre.", date: "Jan 5, 2026", img: "/images/hero.jpg", cat: "Trends" },
  { slug: "earn-coins-fast", title: "5 Ways to Earn Coins Fast on Play VAULT", excerpt: "Level up your rewards with these pro tips.", date: "Dec 28, 2025", img: "/images/promo1.jpg", cat: "Tips" },
];

export function Blog() {
  return (
    <PageShell title="Play VAULT Blog" subtitle="News, guides, and gaming culture" icon="📰" maxWidth="max-w-4xl">
      <SEO title="Free Browser Game Guides and News" description="Browse Play VAULT guides, game lists, browser gaming tips, and new game updates." path="/blog" type="article" />
      <AdUnit variant="leaderboard" className="mb-4 mt-0" />
      <div className="grid gap-4 sm:grid-cols-2">
        {BLOG_POSTS.map((p) => (
          <Link key={p.slug} to={`/blog/${p.slug}`}>
            <Card className="overflow-hidden p-0 transition hover:ring-indigo-500/40">
              <img src={p.img} alt="" className="h-40 w-full object-cover" />
              <div className="p-4">
                <span className="text-xs font-semibold text-indigo-400">{p.cat} · {p.date}</span>
                <h3 className="mt-1 font-bold text-white">{p.title}</h3>
                <p className="mt-1 text-sm text-slate-400">{p.excerpt}</p>
              </div>
            </Card>
          </Link>
        ))}
      </div>
      <ArticleAd className="mt-6" />
    </PageShell>
  );
}

export function BlogPost() {
  const { slug } = useParams();
  const post = BLOG_POSTS.find((p) => p.slug === slug) || BLOG_POSTS[0];
  return (
    <PageShell maxWidth="max-w-2xl">
      <SEO title={post.title} description={post.excerpt} path={`/blog/${post.slug}`} image={post.img} type="article" structuredData={{ "@context": "https://schema.org", "@type": "BlogPosting", headline: post.title, description: post.excerpt, datePublished: post.date, image: post.img, author: { "@type": "Person", name: "Vivek Trivedi" }, publisher: { "@type": "Organization", name: "Play VAULT" }, breadcrumb: breadcrumbSchema([{ name: "Home", path: "/" }, { name: "Blog", path: "/blog" }, { name: post.title, path: `/blog/${post.slug}` }]) }} />
      <Link to="/blog" className="text-sm text-indigo-400 hover:underline">← Back to Blog</Link>
      <img src={post.img} alt="" className="mt-4 h-56 w-full rounded-2xl object-cover" />
      <span className="mt-4 block text-xs font-semibold text-indigo-400">{post.cat} · {post.date}</span>
      <h1 className="mt-1 text-3xl font-extrabold text-white">{post.title}</h1>
      <div className="mt-4 space-y-4 text-sm leading-relaxed text-slate-300">
        <p>{post.excerpt}</p>
        <p>Gaming has never been more accessible. With browser-based HTML5 games, you can jump into thousands of titles instantly — no downloads, no waiting, just pure fun. Play VAULT brings the best of these games together in one place.</p>
        <ArticleAd />
        <p>Whether you love fast-paced action, mind-bending puzzles, or competitive multiplayer .io games, there's something for everyone. Our curated collection is updated regularly with fresh titles from top developers.</p>
        <p>Ready to start? Head to the home page, pick a category, and dive in. Don't forget to save your favorites and earn coins along the way!</p>
      </div>
      <ArticleAd className="mt-6" />
      <div className="mt-2"><Link to="/games"><Btn>Browse Games</Btn></Link></div>
    </PageShell>
  );
}

export function Careers() {
  const jobs = ["Frontend Engineer", "Game Curator", "Community Manager", "UI/UX Designer", "Marketing Lead"];
  return (
    <PageShell title="Careers" subtitle="Join the team building the future of gaming" icon="💼" maxWidth="max-w-2xl">
      <div className="space-y-2">
        {jobs.map((j) => (
          <Card key={j} className="flex items-center justify-between"><div><p className="font-bold text-white">{j}</p><p className="text-xs text-slate-400">Remote · Full-time</p></div><Btn variant="outline">Apply</Btn></Card>
        ))}
      </div>
    </PageShell>
  );
}

export function Press() {
  return (
    <PageShell title="Press & Media" icon="📣" maxWidth="max-w-2xl">
      <Section title="About Play VAULT">
        <p>Play VAULT (owned by Vivek Trivedi) is a leading free-to-play browser gaming platform with 1000+ games and millions of monthly players.</p>
      </Section>
      <Section title="Media Kit">
        <p>Download our logos, screenshots, and brand guidelines for press use.</p>
        <Btn>Download Media Kit</Btn>
      </Section>
      <Section title="Press Contact">
        <p>vivektrivedi236@gmail.com</p>
      </Section>
      <ArticleAd />
    </PageShell>
  );
}
