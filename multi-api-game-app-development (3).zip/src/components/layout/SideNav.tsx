import { NavLink } from "react-router-dom";
import { CATEGORIES } from "../../data/categories";
import { useSiteConfig } from "../../store/SiteConfigContext";
import { SidebarAd } from "../AdPlacements";
import { cn } from "../../utils/cn";
import { categoryPath } from "../../utils/gameUrl";

const MAIN = [
  { to: "/", label: "Home", icon: "🏠", end: true },
  { to: "/games", label: "All Games", icon: "🎮" },
  { to: "/trending", label: "Trending", icon: "🔥" },
  { to: "/new", label: "New Games", icon: "🆕" },
  { to: "/top-rated", label: "Top Rated", icon: "🏆" },
  { to: "/random", label: "Random Game", icon: "🎲" },
];

const PLAY = [
  { to: "/favorites", label: "Favorites", icon: "❤️" },
  { to: "/recent", label: "Recently Played", icon: "🕒" },
  { to: "/daily-challenge", label: "Daily Challenge", icon: "🎯" },
  { to: "/tournaments", label: "Tournaments", icon: "🏅" },
  { to: "/leaderboard", label: "Leaderboard", icon: "📊" },
  { to: "/achievements", label: "Achievements", icon: "🎖️" },
];

const ACCOUNT = [
  { to: "/profile", label: "Profile", icon: "👤" },
  { to: "/wallet", label: "Wallet & Coins", icon: "💰" },
  { to: "/rewards", label: "Rewards", icon: "🎁" },
  { to: "/premium", label: "Go Premium", icon: "👑" },
  { to: "/settings", label: "Settings", icon: "⚙️" },
];

const MORE = [
  { to: "/about", label: "About", icon: "ℹ️" },
  { to: "/blog", label: "Blog", icon: "📰" },
  { to: "/faq", label: "FAQ", icon: "❓" },
  { to: "/contact", label: "Contact", icon: "✉️" },
  { to: "/sitemap", label: "All Pages", icon: "🗺️" },
];

type NavItem = { to: string; label: string; icon: string; end?: boolean };

function NavGroup({ title, items, onNav }: { title: string; items: NavItem[]; onNav: () => void }) {
  return (
    <div className="mb-4">
      <p className="mb-1 px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500">{title}</p>
      <nav className="space-y-0.5">
        {items.map((item) => (
          <NavLink key={item.to} to={item.to} end={item.end} onClick={onNav} className={({ isActive }) => cn("flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition", isActive ? "bg-indigo-600 text-white" : "text-slate-300 hover:bg-slate-800")}>
            <span className="text-base">{item.icon}</span>{item.label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}

export default function SideNav({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { config } = useSiteConfig();
  return (
    <>
      {open && <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={onClose} />}
      <aside className={cn("fixed left-0 top-0 z-40 h-full w-64 shrink-0 overflow-y-auto border-r border-white/10 bg-slate-900 px-2 pt-20 transition-transform lg:sticky lg:top-16 lg:z-0 lg:h-[calc(100vh-4rem)] lg:translate-x-0 lg:pt-4 [scrollbar-width:thin]", open ? "translate-x-0" : "-translate-x-full")}>
        <NavGroup title="Discover" items={MAIN} onNav={onClose} />
        <div className="mb-4"><p className="mb-1 px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500">Categories</p><nav className="space-y-0.5">{CATEGORIES.filter((c) => c.id !== "all" && c.id !== "featured").map((c) => <NavLink key={c.id} to={categoryPath(c.id)} onClick={onClose} className={({ isActive }) => cn("flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition", isActive ? "bg-indigo-600 text-white" : "text-slate-300 hover:bg-slate-800")}><span className="text-base">{c.icon}</span>{c.name}</NavLink>)}</nav></div>
        <NavGroup title="Play" items={PLAY} onNav={onClose} />
        <NavGroup title="Account" items={ACCOUNT} onNav={onClose} />
        <NavGroup title="More" items={MORE} onNav={onClose} />
        {config.customNavLinks.length > 0 && <div className="mb-4"><p className="mb-1 px-3 text-[10px] font-bold uppercase tracking-wider text-amber-400">Featured Links</p><nav className="space-y-0.5">{config.customNavLinks.map((item) => <a key={`${item.label}-${item.url}`} href={item.url} target={item.url.startsWith("http") ? "_blank" : undefined} rel={item.url.startsWith("http") ? "noreferrer" : undefined} onClick={onClose} className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-slate-300 transition hover:bg-slate-800"><span className="text-base">{item.icon || "🔗"}</span>{item.label}</a>)}</nav></div>}
        <SidebarAd />
        <div className="border-t border-white/10 px-3 py-4 text-[11px] text-slate-500"><p>{config.brandName} © 2026 · {config.founderName}</p><p className="mt-1"><NavLink to="/privacy" className="hover:text-slate-300" onClick={onClose}>Privacy</NavLink>{" · "}<NavLink to="/terms" className="hover:text-slate-300" onClick={onClose}>Terms</NavLink></p></div>
      </aside>
    </>
  );
}