import { initializeApp, type FirebaseApp } from "firebase/app";
import { getDatabase, ref, set, get, onValue, update, push, type Database } from "firebase/database";
import { getAnalytics, isSupported, type Analytics } from "firebase/analytics";
import { getAuth, onAuthStateChanged, signInAnonymously, type Auth } from "firebase/auth";

// Play VAULT — Firebase (project: vplay-pro)
const firebaseConfig = {
  apiKey: "AIzaSyBLNW5PVN9pmeO1PkKXyJ7avAM4DEbs-T4",
  authDomain: "vplay-pro.firebaseapp.com",
  databaseURL: "https://vplay-pro-default-rtdb.firebaseio.com",
  projectId: "vplay-pro",
  storageBucket: "vplay-pro.firebasestorage.app",
  messagingSenderId: "177025388415",
  appId: "1:177025388415:web:339c2c74e237bacc57d44a",
  measurementId: "G-W6WWKNQ5Q6",
};

export const app: FirebaseApp = initializeApp(firebaseConfig);
export const db: Database = getDatabase(app);
export const auth: Auth = getAuth(app);

let analyticsInstance: Analytics | null = null;
if (typeof window !== "undefined") {
  isSupported()
    .then((ok) => {
      if (ok) analyticsInstance = getAnalytics(app);
    })
    .catch(() => {});
}
export const getAnalyticsInstance = () => analyticsInstance;

/**
 * Establishes a real Firebase identity for visitors. Enable Anonymous Auth in
 * Firebase Console for cloud-synced favorites and play history; the UI still
 * works locally if authentication is unavailable.
 */
export async function ensureVisitorSession(): Promise<string | null> {
  try {
    if (auth.currentUser) return auth.currentUser.uid;
    const credential = await signInAnonymously(auth);
    return credential.user.uid;
  } catch {
    return null;
  }
}

export function onFirebaseUser(cb: (uid: string | null) => void): () => void {
  return onAuthStateChanged(auth, (user) => cb(user?.uid || null));
}

/* ---- Safe Realtime-DB helpers (never crash the UI) ---- */

export function fbSet(path: string, value: unknown) {
  try {
    set(ref(db, path), value).catch(() => {});
  } catch {
    /* noop */
  }
}

export async function fbGet<T>(path: string): Promise<T | null> {
  try {
    const snap = await get(ref(db, path));
    return snap.exists() ? (snap.val() as T) : null;
  } catch {
    return null;
  }
}

export function fbUpdate(path: string, value: Record<string, unknown>) {
  try {
    update(ref(db, path), value).catch(() => {});
  } catch {
    /* noop */
  }
}

export function fbPush(path: string, value: unknown) {
  try {
    push(ref(db, path), value).catch(() => {});
  } catch {
    /* noop */
  }
}

export function fbOnValue(path: string, cb: (value: unknown) => void): () => void {
  try {
    const r = ref(db, path);
    const unsub = onValue(
      r,
      (s) => cb(s.exists() ? s.val() : null),
      () => {}
    );
    return () => unsub();
  } catch {
    return () => {};
  }
}
