export interface ManagedLink {
  label: string;
  url: string;
  icon?: string;
}

export interface PublicSiteConfig {
  brandName: string;
  brandAccent: string;
  founderName: string;
  supportEmail: string;
  heroBadge: string;
  heroPrimary: ManagedLink;
  heroSecondary: ManagedLink;
  footerLinks: ManagedLink[];
  customNavLinks: ManagedLink[];
  socialLinks: ManagedLink[];
  ads: {
    enabled: boolean;
    leaderboardKey: string;
    bannerKey: string;
    popupEnabled: boolean;
    popupDelaySeconds: number;
    popupFrequencyMinutes: number;
    maxInFeedAds: number;
    disabledSlots: Record<string, boolean>;
  };
}

export const DEFAULT_SITE_CONFIG: PublicSiteConfig = {
  brandName: "Play VAULT",
  brandAccent: "VAULT",
  founderName: "Vivek Trivedi",
  supportEmail: "vivektrivedi236@gmail.com",
  heroBadge: "Play VAULT",
  heroPrimary: { label: "Browse Games", url: "/games" },
  heroSecondary: { label: "Surprise Me", url: "/random" },
  footerLinks: [
    { label: "Help Center", url: "/help" },
    { label: "Contact", url: "/contact" },
    { label: "Privacy", url: "/privacy" },
    { label: "Terms", url: "/terms" },
  ],
  customNavLinks: [],
  socialLinks: [],
  ads: {
    enabled: true,
    leaderboardKey: "3663e208db547fc2fc1193e3a6afba7e",
    bannerKey: "f797eccf5010d58dccbf709e921e996c",
    popupEnabled: true,
    popupDelaySeconds: 45,
    popupFrequencyMinutes: 3,
    maxInFeedAds: 4,
    disabledSlots: {},
  },
};

/** Keeps remote configuration bounded and safe if an admin enters partial data. */
export function normalizeSiteConfig(raw: unknown): PublicSiteConfig {
  const value = (raw || {}) as Partial<PublicSiteConfig>;
  const ads = (value.ads || {}) as Partial<PublicSiteConfig["ads"]>;
  return {
    ...DEFAULT_SITE_CONFIG,
    ...value,
    footerLinks: Array.isArray(value.footerLinks) ? value.footerLinks.slice(0, 8) : DEFAULT_SITE_CONFIG.footerLinks,
    customNavLinks: Array.isArray(value.customNavLinks) ? value.customNavLinks.slice(0, 8) : [],
    socialLinks: Array.isArray(value.socialLinks) ? value.socialLinks.slice(0, 6) : [],
    heroPrimary: { ...DEFAULT_SITE_CONFIG.heroPrimary, ...(value.heroPrimary || {}) },
    heroSecondary: { ...DEFAULT_SITE_CONFIG.heroSecondary, ...(value.heroSecondary || {}) },
    ads: {
      ...DEFAULT_SITE_CONFIG.ads,
      ...ads,
      popupDelaySeconds: Math.min(300, Math.max(15, Number(ads.popupDelaySeconds) || DEFAULT_SITE_CONFIG.ads.popupDelaySeconds)),
      // Popup ads are intentionally bounded to a 2-5 minute range and never run while playing.
      popupFrequencyMinutes: Math.min(5, Math.max(2, Number(ads.popupFrequencyMinutes) || DEFAULT_SITE_CONFIG.ads.popupFrequencyMinutes)),
      maxInFeedAds: Math.min(6, Math.max(0, Number(ads.maxInFeedAds) || DEFAULT_SITE_CONFIG.ads.maxInFeedAds)),
      disabledSlots: typeof ads.disabledSlots === "object" && ads.disabledSlots ? ads.disabledSlots : {},
    },
  };
}