import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import PageShell from "../components/ui/PageShell";
import { Card, Btn, Badge } from "../components/ui/Common";
import { useGames } from "../store/GameContext";
import GameGrid from "../components/ui/GameGrid";
import AdUnit from "../components/AdUnit";
import { gamePath } from "../utils/gameUrl";

export function Leaderboard() {
  const players = [
    { r: 1, n: "ShadowNinja", s: 98420, a: "🥷" },
    { r: 2, n: "PixelQueen", s: 91230, a: "👑" },
    { r: 3, n: "TurboMax", s: 88770, a: "🏎️" },
    { r: 4, n: "You (Player One)", s: 42150, a: "🎮", me: true },
    { r: 5, n: "GhostRider", s: 39800, a: "👻" },
    { r: 6, n: "BlazeFury", s: 35600, a: "🔥" },
    { r: 7, n: "IceBreaker", s: 31200, a: "❄️" },
    { r: 8, n: "MysticFox", s: 28400, a: "🦊" },
  ];
  return (
    <PageShell title="Global Leaderboard" subtitle="Top players this week" icon="📊" maxWidth="max-w-2xl">
      <AdUnit variant="leaderboard" className="mb-4 mt-0" />
      <Card>
        <div className="space-y-2">
          {players.map((p) => (
            <div key={p.r} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 ${p.me ? "bg-indigo-600/30 ring-1 ring-indigo-500" : "bg-slate-900/60"}`}>
              <span className={`w-6 text-center font-black ${p.r <= 3 ? "text-amber-400" : "text-slate-500"}`}>{p.r}</span>
              <span className="text-2xl">{p.a}</span>
              <span className="flex-1 font-semibold text-white">{p.n}</span>
              <span className="text-sm font-bold text-indigo-300">{p.s.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </Card>
    </PageShell>
  );
}

export function DailyChallenge() {
  const { games } = useGames();
  const navigate = useNavigate();
  const daily = games[new Date().getDate() % Math.max(1, games.length)];
  return (
    <PageShell title="Daily Challenge" subtitle="A new game to master every day" icon="🎯" maxWidth="max-w-3xl">
      <AdUnit variant="leaderboard" className="mb-4 mt-0" />
      <div className="mb-6 overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700">
        <div className="flex flex-col items-center gap-4 p-6 text-center sm:flex-row sm:text-left">
          {daily && <img src={daily.thumb} alt="" className="h-28 w-28 rounded-2xl object-cover ring-2 ring-white/30" />}
          <div className="flex-1">
            <Badge color="bg-white/20 text-white">TODAY'S CHALLENGE</Badge>
            <h2 className="mt-2 text-2xl font-extrabold text-white">{daily?.title || "Loading…"}</h2>
            <p className="text-emerald-100">Complete it to earn 🪙 200 bonus coins!</p>
          </div>
          {daily && <Btn variant="ghost" onClick={() => navigate(gamePath(daily))}>▶ Play Now</Btn>}
        </div>
      </div>
      <Card>
        <h3 className="mb-3 font-bold text-white">This Week's Streak</h3>
        <div className="flex justify-between">
          {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
            <div key={i} className="flex flex-col items-center gap-1">
              <div className={`flex h-10 w-10 items-center justify-center rounded-full text-sm font-bold ${i <= new Date().getDay() - 1 ? "bg-emerald-600 text-white" : "bg-slate-700 text-slate-500"}`}>{i <= new Date().getDay() - 1 ? "✓" : d}</div>
            </div>
          ))}
        </div>
      </Card>
    </PageShell>
  );
}

export function Tournaments() {
  const list = [
    { name: "Speed Racers Cup", prize: "🪙 5,000", players: 234, status: "LIVE", color: "bg-rose-500/20 text-rose-300" },
    { name: "Puzzle Masters", prize: "🪙 3,000", players: 189, status: "SOON", color: "bg-amber-500/20 text-amber-300" },
    { name: "Arcade Legends", prize: "🪙 10,000", players: 512, status: "LIVE", color: "bg-rose-500/20 text-rose-300" },
    { name: "Weekend Warriors", prize: "🪙 2,500", players: 98, status: "SOON", color: "bg-amber-500/20 text-amber-300" },
  ];
  return (
    <PageShell title="Tournaments" subtitle="Compete for coins and glory" icon="🏅" maxWidth="max-w-3xl">
      <AdUnit variant="leaderboard" className="mb-4 mt-0" />
      <div className="space-y-3">
        {list.map((t) => (
          <Card key={t.name} className="flex flex-wrap items-center gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2"><h3 className="font-bold text-white">{t.name}</h3><Badge color={t.color}>{t.status}</Badge></div>
              <p className="text-sm text-slate-400">{t.players} players joined</p>
            </div>
            <div className="text-right"><p className="text-xs text-slate-500">Prize Pool</p><p className="font-bold text-amber-400">{t.prize}</p></div>
            <Btn>Join</Btn>
          </Card>
        ))}
      </div>
    </PageShell>
  );
}

export function Notifications() {
  const items = [
    { i: "🎁", t: "Daily reward ready!", d: "Claim your 50 coins", time: "2m ago", unread: true },
    { i: "🏆", t: "New achievement", d: "You unlocked 'On Fire'", time: "1h ago", unread: true },
    { i: "🔥", t: "Trending game", d: "Try Slope Racing 3D now", time: "3h ago", unread: false },
    { i: "🏅", t: "Tournament starting", d: "Arcade Legends begins soon", time: "1d ago", unread: false },
  ];
  return (
    <PageShell title="Notifications" icon="🔔" maxWidth="max-w-2xl">
      <div className="space-y-2">
        {items.map((n, i) => (
          <Card key={i} className={n.unread ? "ring-indigo-500/30" : ""}>
            <div className="flex items-center gap-3">
              <span className="text-2xl">{n.i}</span>
              <div className="flex-1"><p className="font-semibold text-white">{n.t}</p><p className="text-sm text-slate-400">{n.d}</p></div>
              <span className="text-xs text-slate-500">{n.time}</span>
            </div>
          </Card>
        ))}
      </div>
    </PageShell>
  );
}

export function Friends() {
  const friends = [
    { n: "PixelQueen", a: "👑", online: true },
    { n: "TurboMax", a: "🏎️", online: true },
    { n: "GhostRider", a: "👻", online: false },
    { n: "MysticFox", a: "🦊", online: false },
  ];
  return (
    <PageShell title="Friends" subtitle="Play together and compare scores" icon="👥" maxWidth="max-w-2xl">
      <div className="mb-4 flex gap-2">
        <input placeholder="Add friend by username…" className="flex-1 rounded-xl border border-white/10 bg-slate-800 px-4 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
        <Btn>Add</Btn>
      </div>
      <div className="space-y-2">
        {friends.map((f) => (
          <Card key={f.n} className="flex items-center gap-3">
            <div className="relative"><span className="text-3xl">{f.a}</span>{f.online && <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-slate-800 bg-emerald-500" />}</div>
            <div className="flex-1"><p className="font-semibold text-white">{f.n}</p><p className="text-xs text-slate-500">{f.online ? "Online" : "Offline"}</p></div>
            <Link to="/chat"><Btn variant="ghost">Message</Btn></Link>
          </Card>
        ))}
      </div>
    </PageShell>
  );
}

export function Chat() {
  const [msgs, setMsgs] = useState([
    { me: false, t: "Hey! Wanna play Slope Racing?" },
    { me: true, t: "Sure! Starting now 🎮" },
    { me: false, t: "Beat my score of 4200 😎" },
  ]);
  const [text, setText] = useState("");
  return (
    <PageShell title="Chat" icon="💬" maxWidth="max-w-2xl">
      <Card className="flex h-[60vh] flex-col p-0">
        <div className="flex items-center gap-3 border-b border-white/10 p-4"><span className="text-2xl">👑</span><p className="font-bold text-white">PixelQueen</p><span className="ml-auto h-2.5 w-2.5 rounded-full bg-emerald-500" /></div>
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {msgs.map((m, i) => (
            <div key={i} className={`flex ${m.me ? "justify-end" : "justify-start"}`}>
              <span className={`max-w-[75%] rounded-2xl px-4 py-2 text-sm ${m.me ? "bg-indigo-600 text-white" : "bg-slate-700 text-slate-100"}`}>{m.t}</span>
            </div>
          ))}
        </div>
        <form
          onSubmit={(e) => { e.preventDefault(); if (text.trim()) { setMsgs((p) => [...p, { me: true, t: text }]); setText(""); } }}
          className="flex gap-2 border-t border-white/10 p-3"
        >
          <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message…" className="flex-1 rounded-xl border border-white/10 bg-slate-900 px-4 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
          <Btn type="submit">Send</Btn>
        </form>
      </Card>
    </PageShell>
  );
}

export function Feedback() {
  const [sent, setSent] = useState(false);
  return (
    <PageShell title="Send Feedback" subtitle="Help us make Play VAULT better" icon="📝" maxWidth="max-w-xl">
      {sent ? (
        <Card className="text-center"><div className="text-5xl">🙏</div><p className="mt-3 text-lg font-bold text-white">Thank you!</p><p className="text-slate-400">Your feedback has been received.</p></Card>
      ) : (
        <Card>
          <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="space-y-3">
            <select className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500">
              <option>Bug Report</option><option>Feature Request</option><option>Game Suggestion</option><option>Other</option>
            </select>
            <div className="flex gap-2">{["😞", "😐", "🙂", "😍"].map((e) => <button key={e} type="button" className="flex-1 rounded-lg bg-slate-900/60 py-3 text-2xl transition hover:bg-slate-700">{e}</button>)}</div>
            <textarea rows={5} placeholder="Tell us what's on your mind…" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
            <Btn type="submit" className="w-full">Submit Feedback</Btn>
          </form>
        </Card>
      )}
    </PageShell>
  );
}

export function GiftCards() {
  const cards = [
    { v: "$10", coins: "1,200", color: "from-blue-500 to-cyan-600" },
    { v: "$25", coins: "3,500", color: "from-violet-500 to-purple-600" },
    { v: "$50", coins: "8,000", color: "from-amber-500 to-orange-600" },
    { v: "$100", coins: "18,000", color: "from-rose-500 to-pink-600" },
  ];
  return (
    <PageShell title="Gift Cards" subtitle="Give the gift of gaming" icon="🎴" maxWidth="max-w-3xl">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {cards.map((c) => (
          <div key={c.v} className={`rounded-2xl bg-gradient-to-br ${c.color} p-5 text-center`}>
            <p className="text-3xl font-black text-white">{c.v}</p>
            <p className="text-sm text-white/80">🪙 {c.coins}</p>
            <Btn variant="ghost" className="mt-3 w-full">Buy</Btn>
          </div>
        ))}
      </div>
    </PageShell>
  );
}

export function Redeem() {
  const [code, setCode] = useState("");
  const [msg, setMsg] = useState("");
  return (
    <PageShell title="Redeem Code" subtitle="Enter a gift or promo code" icon="🎟️" maxWidth="max-w-md">
      <Card>
        <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="XXXX-XXXX-XXXX" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-3 text-center font-mono text-lg tracking-widest text-white outline-none focus:border-indigo-500" />
        <Btn className="mt-3 w-full" onClick={() => setMsg(code ? "❌ Invalid or expired code. Try 'WELCOME2026'!" : "Please enter a code.")}>Redeem</Btn>
        {msg && <p className="mt-3 text-center text-sm text-amber-400">{msg}</p>}
      </Card>
    </PageShell>
  );
}

export function Onboarding() {
  const { games } = useGames();
  return (
    <PageShell title="Welcome to Play VAULT! 🎉" subtitle="Let's get you started" icon="" maxWidth="max-w-3xl">
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        {[
          { i: "🎮", t: "Play Instantly", d: "No downloads, 1000+ games in your browser" },
          { i: "❤️", t: "Save Favorites", d: "Build your personal game library" },
          { i: "🏆", t: "Earn Rewards", d: "Level up, earn coins, unlock perks" },
        ].map((s) => (
          <Card key={s.t} className="text-center"><div className="text-4xl">{s.i}</div><p className="mt-2 font-bold text-white">{s.t}</p><p className="text-sm text-slate-400">{s.d}</p></Card>
        ))}
      </div>
      <p className="mb-3 font-bold text-white">🔥 Popular picks to start with:</p>
      <GameGrid games={games.slice(0, 8)} />
      <div className="mt-6 text-center"><Link to="/"><Btn>Start Exploring →</Btn></Link></div>
    </PageShell>
  );
}
