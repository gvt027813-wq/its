const { getAdmin } = require('../lib/firebaseAdmin');

function requestId(req, res, next) {
  req.requestId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  res.setHeader('X-Request-Id', req.requestId);
  next();
}

async function requireAuth(req, res, next) {
  const header = req.get('authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Authentication required', requestId: req.requestId });
  try {
    req.user = await getAdmin().auth().verifyIdToken(token, true);
    return next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired authentication token', requestId: req.requestId });
  }
}

function requireAdmin(req, res, next) {
  if (req.user?.admin === true) return next();
  return res.status(403).json({ error: 'Administrator permission required', requestId: req.requestId });
}

module.exports = { requestId, requireAuth, requireAdmin };