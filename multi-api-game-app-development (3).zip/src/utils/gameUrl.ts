import type { Game } from "../types";

export function slugify(value: string) {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80) || "game";
}

/** SEO-readable, stable game URL. The id suffix prevents duplicate-title collisions. */
export function gameSlug(game: Game) {
  return `${slugify(game.title)}--${encodeURIComponent(game.id.toLowerCase())}`;
}

export function gamePath(game: Game) {
  return `/games/${encodeURIComponent(game.category)}/${gameSlug(game)}`;
}

export function categoryPath(category: string) {
  return `/games/${encodeURIComponent(category)}`;
}

export function gameIdFromSlug(slug: string) {
  const delimiter = slug.lastIndexOf("--");
  if (delimiter < 1) return null;
  try {
    return decodeURIComponent(slug.slice(delimiter + 2)).toLowerCase();
  } catch {
    return null;
  }
}