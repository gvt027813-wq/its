import type { CategoryInfo } from "../types";

export const CATEGORIES: CategoryInfo[] = [
  { id: "all", name: "All Games", icon: "🎮", color: "from-violet-500 to-indigo-600" },
  { id: "featured", name: "Featured", icon: "⭐", color: "from-amber-400 to-orange-500" },
  { id: "action", name: "Action", icon: "💥", color: "from-rose-500 to-red-600" },
  { id: "puzzle", name: "Puzzle", icon: "🧩", color: "from-emerald-500 to-teal-600" },
  { id: "racing", name: "Racing", icon: "🏎️", color: "from-blue-500 to-cyan-600" },
  { id: "sports", name: "Sports", icon: "⚽", color: "from-green-500 to-lime-600" },
  { id: "arcade", name: "Arcade", icon: "👾", color: "from-fuchsia-500 to-pink-600" },
  { id: "shooting", name: "Shooting", icon: "🎯", color: "from-orange-500 to-amber-600" },
  { id: "adventure", name: "Adventure", icon: "🗺️", color: "from-teal-500 to-cyan-600" },
  { id: "girls", name: "Girls", icon: "💄", color: "from-pink-500 to-rose-500" },
  { id: "strategy", name: "Strategy", icon: "♟️", color: "from-slate-500 to-gray-700" },
  { id: "board", name: "Board", icon: "🎲", color: "from-indigo-500 to-purple-600" },
  { id: "casual", name: "Casual", icon: "🎈", color: "from-sky-500 to-blue-600" },
  { id: "io", name: ".io Games", icon: "🌐", color: "from-cyan-500 to-teal-600" },
];

// Map various source categories to our normalized categories
export function normalizeCategory(raw: string): string {
  const c = (raw || "").toLowerCase();
  if (/action|fight|war|battle/.test(c)) return "action";
  if (/puzzle|match|brain|logic|blocks/.test(c)) return "puzzle";
  if (/rac|car|drive|drift|bike|moto/.test(c)) return "racing";
  if (/sport|soccer|football|basket|golf|pool/.test(c)) return "sports";
  if (/arcade|classic|retro/.test(c)) return "arcade";
  if (/shoot|gun|sniper|zombie/.test(c)) return "shooting";
  if (/adventure|rpg|quest|escape/.test(c)) return "adventure";
  if (/girl|dress|makeup|fashion|beauty/.test(c)) return "girls";
  if (/strategy|tower|defense|manage/.test(c)) return "strategy";
  if (/board|card|chess|checker|domino/.test(c)) return "board";
  if (/io|multiplayer/.test(c)) return "io";
  return "casual";
}
