import { useState, useEffect } from "react";
import { Outlet, useLocation } from "react-router-dom";
import TopBar from "./TopBar";
import SideNav from "./SideNav";
import BottomNav from "./BottomNav";
import Footer from "./Footer";
import AdPopup from "../AdPopup";

export default function Layout() {
  const [navOpen, setNavOpen] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    setNavOpen(false);
  }, [pathname]);

  return (
    <div className="relative min-h-screen bg-slate-950 text-white">
      {/* ambient vault-gold glow layers */}
      <div className="pointer-events-none fixed inset-0 z-0 bg-[radial-gradient(1000px_500px_at_85%_-5%,rgba(223,162,63,0.09),transparent_60%),radial-gradient(800px_420px_at_-5%_105%,rgba(178,111,27,0.07),transparent_60%)]" />

      <div className="relative z-10">
        <TopBar onMenu={() => setNavOpen(true)} />
        <div className="mx-auto flex max-w-[1600px]">
          <SideNav open={navOpen} onClose={() => setNavOpen(false)} />
          <main className="min-w-0 flex-1 px-3 pb-24 pt-5 sm:px-6 lg:pb-10">
            <Outlet />
            <Footer />
          </main>
        </div>
        <BottomNav />
        <AdPopup />
      </div>
    </div>
  );
}
