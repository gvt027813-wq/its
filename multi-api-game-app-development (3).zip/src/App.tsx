import { BrowserRouter, Routes, Route } from "react-router-dom";
import { GameProvider } from "./store/GameContext";
import { SiteConfigProvider } from "./store/SiteConfigContext";
import Layout from "./components/layout/Layout";

import Home from "./pages/Home";
import AllGames from "./pages/AllGames";
import CategoryPage from "./pages/CategoryPage";
import GameDetail from "./pages/GameDetail";
import { Trending, NewGames, TopRated, Favorites, Recent, SearchPage, RandomGame } from "./pages/ListPages";
import { Profile, Settings, Wallet, Rewards, Premium, Achievements } from "./pages/AccountPages";
import { Leaderboard, DailyChallenge, Tournaments, Notifications, Friends, Chat, Feedback, GiftCards, Redeem, Onboarding } from "./pages/FeaturePages";
import { About, Contact, FAQ, Help, Blog, BlogPost, Careers, Press } from "./pages/InfoPages";
import { Partners, Advertise } from "./pages/DeveloperPages";
import { Privacy, Terms, Cookies, DMCA, CommunityGuidelines, Disclaimer, RefundPolicy } from "./pages/LegalPages";
import { Login, Signup, ForgotPassword, NotFound, ComingSoon, Maintenance, Sitemap } from "./pages/AuthUtilPages";
import { LegacyCategoryRedirect, LegacyGameRedirect } from "./pages/LegacyRedirects";

export default function App() {
  return (
    <SiteConfigProvider>
      <GameProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            {/* Discover */}
            <Route path="/" element={<Home />} />
            <Route path="/games" element={<AllGames />} />
            <Route path="/games/:category/:slug" element={<GameDetail />} />
            <Route path="/games/:id" element={<CategoryPage />} />
            {/* Legacy links stay usable but redirect to the canonical SEO URLs. */}
            <Route path="/category/:id" element={<LegacyCategoryRedirect />} />
            <Route path="/game/:id" element={<LegacyGameRedirect />} />
            <Route path="/trending" element={<Trending />} />
            <Route path="/new" element={<NewGames />} />
            <Route path="/top-rated" element={<TopRated />} />
            <Route path="/random" element={<RandomGame />} />
            <Route path="/search" element={<SearchPage />} />

            {/* Play */}
            <Route path="/favorites" element={<Favorites />} />
            <Route path="/recent" element={<Recent />} />
            <Route path="/daily-challenge" element={<DailyChallenge />} />
            <Route path="/tournaments" element={<Tournaments />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
            <Route path="/achievements" element={<Achievements />} />

            {/* Account */}
            <Route path="/profile" element={<Profile />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/wallet" element={<Wallet />} />
            <Route path="/rewards" element={<Rewards />} />
            <Route path="/premium" element={<Premium />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/friends" element={<Friends />} />
            <Route path="/chat" element={<Chat />} />
            <Route path="/gift-cards" element={<GiftCards />} />
            <Route path="/redeem" element={<Redeem />} />
            <Route path="/feedback" element={<Feedback />} />

            {/* Info */}
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/help" element={<Help />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogPost />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/press" element={<Press />} />

            {/* Business */}
            <Route path="/partners" element={<Partners />} />
            <Route path="/advertise" element={<Advertise />} />

            {/* Auth */}
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/onboarding" element={<Onboarding />} />

            {/* Legal */}
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/cookies" element={<Cookies />} />
            <Route path="/dmca" element={<DMCA />} />
            <Route path="/community-guidelines" element={<CommunityGuidelines />} />
            <Route path="/disclaimer" element={<Disclaimer />} />
            <Route path="/refund-policy" element={<RefundPolicy />} />

            {/* Utility */}
            <Route path="/sitemap" element={<Sitemap />} />
            <Route path="/coming-soon" element={<ComingSoon />} />
            <Route path="/maintenance" element={<Maintenance />} />
            <Route path="/404" element={<NotFound />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </BrowserRouter>
      </GameProvider>
    </SiteConfigProvider>
  );
}
