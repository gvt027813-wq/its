# Play VAULT: Secure Three-Site Deployment

## Site Separation

| Site | Hosting target | Purpose | Who can access |
|---|---|---|---|
| `playvault.gg` | `public` | Player-facing website | Everyone |
| `admin.playvault.gg` | `admin` | Website, ad, link and game-review control center | Firebase users with `admin: true` custom claim |
| `developers.playvault.gg` | `developers` | Developer sign-in and game submission portal | Registered email/password users |

The public React app has no `/admin`, `/submit-game`, or `/developers` route.

## One-Time Firebase Setup

1. In **Firebase Authentication**, enable **Anonymous** and **Email/Password** providers.
2. Create the owner account using `vivektrivedi236@gmail.com` in Firebase Authentication.
3. Create a Firebase service account in a trusted environment. Do not commit its JSON file.
4. Set `FIREBASE_SERVICE_ACCOUNT` to the service-account JSON in your server/CI secret manager.
5. Grant the owner account the claim:

```bash
node backend/scripts/setAdminClaim.js vivektrivedi236@gmail.com
```

6. Sign out and sign in to `admin.playvault.gg` again, so Firebase issues a token containing `admin: true`.
7. Seed live public controls once:

```bash
node backend/scripts/seedSiteConfig.js
```

8. Deploy RTDB rules before opening either portal:

```bash
firebase deploy --only database
```

## Hosting Deployment

Build the public app first:

```bash
npm run build
firebase target:apply hosting public YOUR_PUBLIC_FIREBASE_SITE
firebase target:apply hosting admin YOUR_ADMIN_FIREBASE_SITE
firebase target:apply hosting developers YOUR_DEVELOPER_FIREBASE_SITE
firebase deploy --only hosting
```

Map the three Firebase Hosting sites to `playvault.gg`, `admin.playvault.gg`, and `developers.playvault.gg` in Firebase Hosting custom-domain settings.

## Secured API

Set these server secrets:

```text
MONGO_URI=mongodb+srv://...
FIREBASE_SERVICE_ACCOUNT={"type":"service_account",...}
CLIENT_ORIGINS=https://playvault.gg,https://admin.playvault.gg,https://developers.playvault.gg
PORT=5000
```

Routes:

| Endpoint | Protection |
|---|---|
| `GET /api/v1/games` | Public, rate limited, bounded pagination |
| `POST /api/v1/games` | Firebase ID token required; Zod-validated submission |
| `PUT /api/v1/games/:id/verify` | Firebase ID token + `admin: true` claim |

The API enables Helmet, trusted-origin CORS, request IDs, 15-minute rate limiting, strict 32 KB request bodies, bounded pagination, allowed-field validation, and non-leaking error responses.

## Ad Policy

The website has more than 20 managed banner placements across pages, but it deliberately avoids an abusive "20 ads on one screen" pattern. Ads load only near the viewport; the in-site popup is labelled, dismissible, skipped during gameplay, and capped by admin-controlled delay/frequency. Premium users never load ad scripts.

Admin controls live from `admin.playvault.gg`:

- Global advertising enable/disable
- Both banner provider keys
- Popup enable, delay and 2-5 minute frequency cap
- Per-grid maximum in-feed ads
- Brand, owner email, header, hero buttons, footer links and custom navigation
- Developer-submitted game review status

## Important

- Firebase web API keys are identifiers, not secrets. The deployed RTDB rules and server-side Admin SDK authorization are the security boundary.
- Never set `admin: true` from frontend code or in Realtime Database.
- Never expose `FIREBASE_SERVICE_ACCOUNT` in any frontend or portal file.
- Review the third-party ad provider's policies and use a consent banner where required by your visitor jurisdictions.