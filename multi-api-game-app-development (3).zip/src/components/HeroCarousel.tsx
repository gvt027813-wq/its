import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { Game } from "../types";

interface Slide {
  image: string;
  title: string;
  subtitle: string;
  accent: string;
}

const SLIDES: Slide[] = [
  {
    image: "/images/hero.jpg",
    title: "1000+ Free Online Games. Zero Downloads.",
    subtitle: "Play the best browser action, racing, puzzle, sports & .io games instantly on VaultPlays (Play VAULT).",
    accent: "from-amber-600/80",
  },
  {
    image: "/images/promo1.jpg",
    title: "Feel the Speed & Nitro",
    subtitle: "Race through neon cities and drift through high-speed tracks in free online car racing games.",
    accent: "from-blue-600/80",
  },
  {
    image: "/images/promo2.jpg",
    title: "Master Logic & Brain Puzzles",
    subtitle: "Challenge your mind with brain-teasing puzzle & strategy games built for quick browser sessions.",
    accent: "from-emerald-600/80",
  },
];

interface Props {
  onPlayRandom: () => void;
  featured?: Game;
  onPlayFeatured?: (g: Game) => void;
}

export default function HeroCarousel({ onPlayRandom, featured, onPlayFeatured }: Props) {
  const [i, setI] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % SLIDES.length), 6000);
    return () => clearInterval(t);
  }, []);

  const s = SLIDES[i];

  return (
    <div className="relative h-72 overflow-hidden rounded-3xl border border-amber-500/25 bg-slate-900 shadow-2xl ring-1 ring-white/10 sm:h-88 md:h-[400px]">
      {SLIDES.map((slide, idx) => (
        <img
          key={idx}
          src={slide.image}
          alt={idx === i ? "Play free online browser games on VaultPlays Play VAULT" : ""}
          aria-hidden={idx !== i}
          className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${idx === i ? "opacity-100" : "opacity-0"}`}
        />
      ))}
      <div className={`absolute inset-0 bg-gradient-to-r ${s.accent} via-slate-950/70 to-slate-950/95`} />

      <div className="relative z-10 flex h-full flex-col justify-center px-6 sm:px-12 md:px-16">
        <div className="mb-3 flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-400/40 bg-slate-950/70 px-3.5 py-1 text-xs font-bold text-amber-300 backdrop-blur-md shadow-md">
            <span>🔥</span> VaultPlays · Play VAULT
          </span>
          <span className="hidden rounded-full bg-emerald-500/20 px-2.5 py-1 text-[11px] font-extrabold text-emerald-400 border border-emerald-500/30 sm:inline-block">
            ⚡ Instant Play
          </span>
        </div>

        <h1 className="max-w-xl font-display text-2xl font-black leading-tight text-white drop-shadow-md sm:text-4xl md:text-5xl">
          {s.title}
        </h1>
        <p className="mt-2.5 max-w-lg text-sm text-slate-200 drop-shadow sm:text-base">{s.subtitle}</p>

        <div className="mt-6 flex flex-wrap gap-3">
          <button
            onClick={() => (featured && onPlayFeatured ? onPlayFeatured(featured) : navigate("/games"))}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 px-6 py-3 font-display text-sm font-extrabold text-slate-950 shadow-xl transition hover:scale-105 hover:brightness-110"
          >
            <span>▶</span> Play Featured Game
          </button>
          <button
            onClick={onPlayRandom}
            className="flex items-center gap-2 rounded-xl border border-white/20 bg-slate-900/60 px-5 py-3 text-sm font-bold text-white backdrop-blur-md transition hover:bg-slate-800/80 hover:border-amber-400/40"
          >
            <span>🎲</span> Surprise Me
          </button>
        </div>
      </div>

      <div className="absolute bottom-5 left-1/2 z-10 flex -translate-x-1/2 gap-2">
        {SLIDES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setI(idx)}
            className={`h-2.5 rounded-full transition-all ${idx === i ? "w-8 bg-amber-400" : "w-2.5 bg-white/40 hover:bg-white/70"}`}
            aria-label={`Go to slide ${idx + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
