import { Navigate, useParams } from "react-router-dom";
import { useGames } from "../store/GameContext";
import { categoryPath, gamePath } from "../utils/gameUrl";
import PageShell from "../components/ui/PageShell";
import { Loader } from "../components/ui/Common";

export function LegacyGameRedirect() {
  const { id = "" } = useParams();
  const { getGame, loading } = useGames();
  const game = getGame(decodeURIComponent(id));
  if (loading) return <PageShell><Loader label="Opening game…" /></PageShell>;
  return <Navigate to={game ? gamePath(game) : "/games"} replace />;
}

export function LegacyCategoryRedirect() {
  const { id = "" } = useParams();
  return <Navigate to={categoryPath(id)} replace />;
}