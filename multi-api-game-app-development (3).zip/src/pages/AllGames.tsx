import { useMemo, useState } from "react";
import { useGames } from "../store/GameContext";
import GameGrid from "../components/ui/GameGrid";
import PageShell from "../components/ui/PageShell";
import { SkeletonGrid, Btn } from "../components/ui/Common";
import { CATEGORIES } from "../data/categories";
import { cn } from "../utils/cn";
import AdUnit from "../components/AdUnit";
import SEO from "../components/SEO";

type Sort = "popular" | "rating" | "az" | "new";

export default function AllGames() {
  const { games, loading } = useGames();
  const [cat, setCat] = useState("all");
  const [sort, setSort] = useState<Sort>("popular");
  const [visible, setVisible] = useState(48);

  const filtered = useMemo(() => {
    let list = cat === "all" ? games : games.filter((g) => g.category === cat);
    list = [...list];
    if (sort === "popular") list.sort((a, b) => (b.plays || 0) - (a.plays || 0));
    else if (sort === "rating") list.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    else if (sort === "az") list.sort((a, b) => a.title.localeCompare(b.title));
    return list;
  }, [games, cat, sort]);

  return (
    <PageShell title="All Games" subtitle={`Browse ${games.length.toLocaleString()}+ free online games`} icon="🎮" maxWidth="max-w-none">
      <SEO title="Free Online Games" description="Browse 1000+ free online games. Play action, arcade, puzzle, racing, sports, and casual browser games with no download." path="/games" />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="-mx-1 flex flex-1 gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {CATEGORIES.filter((c) => c.id !== "featured").map((c) => (
            <button
              key={c.id}
              onClick={() => {
                setCat(c.id);
                setVisible(48);
              }}
              className={cn(
                "flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-xs font-semibold transition",
                cat === c.id ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
              )}
            >
              <span>{c.icon}</span>
              {c.name}
            </button>
          ))}
        </div>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as Sort)}
          className="rounded-xl border border-white/10 bg-slate-800 px-3 py-2 text-sm text-white outline-none"
        >
          <option value="popular">Most Popular</option>
          <option value="rating">Top Rated</option>
          <option value="az">A → Z</option>
        </select>
      </div>

      <AdUnit variant="leaderboard" className="my-4" slotId="all-games-top" />

      {loading ? (
        <SkeletonGrid count={32} />
      ) : (
        <>
          <GameGrid games={filtered.slice(0, visible)} />
          {visible < filtered.length && (
            <div className="mt-8 flex justify-center">
              <Btn onClick={() => setVisible((v) => v + 48)}>Load More ({filtered.length - visible} left)</Btn>
            </div>
          )}
        </>
      )}
    </PageShell>
  );
}
