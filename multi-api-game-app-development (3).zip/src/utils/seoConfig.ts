const trimTrailingSlash = (value: string) => value.replace(/\/$/, "");

const configuredSiteUrl = typeof document !== "undefined" ? document.documentElement.dataset.siteUrl : undefined;
const runtimeOrigin = typeof window !== "undefined" ? window.location.origin : undefined;

export const SEO_CONFIG = {
  siteUrl: trimTrailingSlash(configuredSiteUrl || runtimeOrigin || "https://vaultplays.netlify.app"),
  siteName: "VaultPlays · Play VAULT",
  brandAliases: ["VaultPlays", "Play VAULT", "Vault Play", "Play Vault", "VaultPlay", "Vault Games", "PlayVault"],
  owner: "Vivek Trivedi",
  ownerEmail: "vivektrivedi236@gmail.com",
  defaultTitle: "Free Online Games — Play 1000+ Games | VaultPlays & Play VAULT",
  defaultDesc: "Play free online games instantly on VaultPlays (Play VAULT). Enjoy 1000+ action, racing, puzzle, sports, arcade, shooting and .io games. No download, no install, 100% free browser play.",
  defaultKeywords: [
    "VaultPlays", "Play VAULT", "Vault Play", "Play Vault", "VaultPlay", "Vault Games", "PlayVault",
    "free online games", "online games", "browser games", "free games no download", "free HTML5 games",
    "instant play games", "best browser games 2026", "free action games", "free racing games", "free puzzle games",
    "free arcade games", "free sports games", "free shooting games", "free adventure games", "free .io games",
    "free casual games", "2 player browser games", "unblocked games free", "mobile browser games free"
  ].join(", "),
  twitterHandle: "@playvault",
  defaultImage: "/images/hero.jpg",
};

export function absoluteUrl(path = "/") {
  if (/^https?:\/\//i.test(path)) return path;
  return new URL(path.startsWith("/") ? path : `/${path}`, `${SEO_CONFIG.siteUrl}/`).toString();
}

export function buildPageMeta(title?: string, description?: string) {
  return {
    title: title ? `${title} | VaultPlays (Play VAULT)` : SEO_CONFIG.defaultTitle,
    description: description || SEO_CONFIG.defaultDesc,
    keywords: SEO_CONFIG.defaultKeywords,
    image: absoluteUrl(SEO_CONFIG.defaultImage),
  };
}

export function websiteSchema() {
  return {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebSite",
        "@id": `${SEO_CONFIG.siteUrl}/#website`,
        name: "VaultPlays",
        alternateName: SEO_CONFIG.brandAliases,
        url: SEO_CONFIG.siteUrl,
        description: SEO_CONFIG.defaultDesc,
        publisher: {
          "@type": "Organization",
          "@id": `${SEO_CONFIG.siteUrl}/#organization`,
          name: "VaultPlays / Play VAULT",
          alternateName: SEO_CONFIG.brandAliases,
          url: SEO_CONFIG.siteUrl,
          founder: { "@type": "Person", name: SEO_CONFIG.owner, email: SEO_CONFIG.ownerEmail },
          logo: {
            "@type": "ImageObject",
            url: absoluteUrl("/images/logo.png"),
            caption: "VaultPlays Logo",
          },
        },
        potentialAction: {
          "@type": "SearchAction",
          target: {
            "@type": "EntryPoint",
            urlTemplate: `${SEO_CONFIG.siteUrl}/search?q={search_term_string}`,
          },
          "query-input": "required name=search_term_string",
        },
      },
      {
        "@type": "Organization",
        "@id": `${SEO_CONFIG.siteUrl}/#organization`,
        name: "VaultPlays",
        alternateName: SEO_CONFIG.brandAliases,
        url: SEO_CONFIG.siteUrl,
        logo: absoluteUrl("/images/logo.png"),
        email: SEO_CONFIG.ownerEmail,
        founder: { "@type": "Person", name: SEO_CONFIG.owner },
      },
    ],
  };
}

export function breadcrumbSchema(items: Array<{ name: string; path: string }>) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: absoluteUrl(item.path),
    })),
  };
}
