import { Link, useNavigate } from "react-router-dom";
import PageShell from "../components/ui/PageShell";
import { Card, Btn } from "../components/ui/Common";
import { CATEGORIES } from "../data/categories";

function AuthShell({ title, sub, children, footer }: { title: string; sub: string; children: React.ReactNode; footer: React.ReactNode }) {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center">
      <div className="mb-6 text-center">
        <img src="/images/logo.png" alt="" className="mx-auto h-14 w-14 rounded-2xl" />
        <h1 className="mt-3 text-2xl font-extrabold text-white">{title}</h1>
        <p className="text-sm text-slate-400">{sub}</p>
      </div>
      <Card>{children}</Card>
      <div className="mt-4 text-center text-sm text-slate-400">{footer}</div>
    </div>
  );
}

export function Login() {
  const nav = useNavigate();
  return (
    <AuthShell title="Welcome Back" sub="Sign in to continue playing" footer={<>Don't have an account? <Link to="/signup" className="text-indigo-400 hover:underline">Sign up</Link></>}>
      <form onSubmit={(e) => { e.preventDefault(); nav("/profile"); }} className="space-y-3">
        <input placeholder="Email" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
        <input type="password" placeholder="Password" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
        <div className="text-right"><Link to="/forgot-password" className="text-xs text-indigo-400 hover:underline">Forgot password?</Link></div>
        <Btn type="submit" className="w-full">Sign In</Btn>
        <div className="flex gap-2"><Btn variant="outline" className="w-full">🔵 Google</Btn><Btn variant="outline" className="w-full"> Apple</Btn></div>
      </form>
    </AuthShell>
  );
}

export function Signup() {
  const nav = useNavigate();
  return (
    <AuthShell title="Create Account" sub="Join millions of players for free" footer={<>Already registered? <Link to="/login" className="text-indigo-400 hover:underline">Sign in</Link></>}>
      <form onSubmit={(e) => { e.preventDefault(); nav("/onboarding"); }} className="space-y-3">
        <input placeholder="Username" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
        <input placeholder="Email" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
        <input type="password" placeholder="Password" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
        <Btn type="submit" className="w-full">Create Account</Btn>
        <p className="text-center text-xs text-slate-500">By signing up you agree to our <Link to="/terms" className="text-indigo-400">Terms</Link></p>
      </form>
    </AuthShell>
  );
}

export function ForgotPassword() {
  return (
    <AuthShell title="Reset Password" sub="We'll email you a reset link" footer={<Link to="/login" className="text-indigo-400 hover:underline">Back to sign in</Link>}>
      <form onSubmit={(e) => e.preventDefault()} className="space-y-3">
        <input placeholder="Your email" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none focus:border-indigo-500" />
        <Btn type="submit" className="w-full">Send Reset Link</Btn>
      </form>
    </AuthShell>
  );
}

export function NotFound() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
      <div className="text-8xl">🎮</div>
      <h1 className="text-4xl font-black text-white">404</h1>
      <p className="text-slate-400">This page went off the grid. Let's get you back in the game.</p>
      <Link to="/"><Btn>Back to Home</Btn></Link>
    </div>
  );
}

export function ComingSoon() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
      <div className="text-7xl">🚧</div>
      <h1 className="text-3xl font-black text-white">Coming Soon</h1>
      <p className="text-slate-400">We're building something awesome. Check back later!</p>
      <Link to="/"><Btn>Back to Home</Btn></Link>
    </div>
  );
}

export function Maintenance() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
      <div className="text-7xl">🛠️</div>
      <h1 className="text-3xl font-black text-white">Under Maintenance</h1>
      <p className="text-slate-400">Play VAULT is getting an upgrade. Back online shortly!</p>
    </div>
  );
}

const SITE_MAP: { group: string; links: { to: string; label: string }[] }[] = [
  { group: "Discover", links: [
    { to: "/", label: "Home" }, { to: "/games", label: "All Games" }, { to: "/trending", label: "Trending" },
    { to: "/new", label: "New Games" }, { to: "/top-rated", label: "Top Rated" }, { to: "/random", label: "Random Game" },
  ] },
  { group: "Categories", links: CATEGORIES.filter((c) => c.id !== "all" && c.id !== "featured").map((c) => ({ to: `/games/${c.id}`, label: c.name })) },
  { group: "Play", links: [
    { to: "/favorites", label: "Favorites" }, { to: "/recent", label: "Recently Played" }, { to: "/daily-challenge", label: "Daily Challenge" },
    { to: "/tournaments", label: "Tournaments" }, { to: "/leaderboard", label: "Leaderboard" }, { to: "/achievements", label: "Achievements" },
  ] },
  { group: "Account", links: [
    { to: "/profile", label: "Profile" }, { to: "/wallet", label: "Wallet" }, { to: "/rewards", label: "Rewards" },
    { to: "/premium", label: "Premium" }, { to: "/settings", label: "Settings" }, { to: "/notifications", label: "Notifications" },
    { to: "/friends", label: "Friends" }, { to: "/chat", label: "Chat" }, { to: "/gift-cards", label: "Gift Cards" }, { to: "/redeem", label: "Redeem Code" },
  ] },
  { group: "Auth", links: [
    { to: "/login", label: "Login" }, { to: "/signup", label: "Sign Up" }, { to: "/forgot-password", label: "Forgot Password" }, { to: "/onboarding", label: "Onboarding" },
  ] },
  { group: "Company", links: [
    { to: "/about", label: "About" }, { to: "/blog", label: "Blog" }, { to: "/careers", label: "Careers" }, { to: "/press", label: "Press" },
    { to: "/contact", label: "Contact" }, { to: "/faq", label: "FAQ" }, { to: "/help", label: "Help Center" }, { to: "/feedback", label: "Feedback" },
  ] },
  { group: "Business", links: [
    { to: "/partners", label: "Partners" }, { to: "/advertise", label: "Advertise" },
  ] },
  { group: "Legal", links: [
    { to: "/privacy", label: "Privacy Policy" }, { to: "/terms", label: "Terms of Service" }, { to: "/cookies", label: "Cookie Policy" },
    { to: "/dmca", label: "DMCA" }, { to: "/community-guidelines", label: "Community Guidelines" }, { to: "/disclaimer", label: "Disclaimer" }, { to: "/refund-policy", label: "Refund Policy" },
  ] },
  { group: "Utility", links: [
    { to: "/coming-soon", label: "Coming Soon" }, { to: "/maintenance", label: "Maintenance" }, { to: "/404", label: "404 Page" },
  ] },
];

export function Sitemap() {
  return (
    <PageShell title="All Pages" subtitle="Every page in Play VAULT" icon="🗺️" maxWidth="max-w-5xl">
      <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3">
        {SITE_MAP.map((g) => (
          <div key={g.group}>
            <h3 className="mb-2 text-sm font-bold uppercase tracking-wider text-indigo-400">{g.group}</h3>
            <ul className="space-y-1">
              {g.links.map((l) => (
                <li key={l.to + l.label}><Link to={l.to} className="text-sm text-slate-300 hover:text-white hover:underline">{l.label}</Link></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </PageShell>
  );
}
