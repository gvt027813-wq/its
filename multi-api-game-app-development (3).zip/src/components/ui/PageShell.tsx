import { motion } from "framer-motion";
import type { ReactNode } from "react";

interface Props {
  title?: string;
  subtitle?: string;
  icon?: string;
  children: ReactNode;
  maxWidth?: string;
}

export default function PageShell({ title, subtitle, icon, children, maxWidth = "max-w-5xl" }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`mx-auto w-full ${maxWidth}`}
    >
      {title && (
        <div className="mb-6">
          <h1 className="flex items-center gap-2 text-2xl font-extrabold text-white sm:text-3xl">
            {icon && <span>{icon}</span>}
            {title}
          </h1>
          {subtitle && <p className="mt-1 text-sm text-slate-400">{subtitle}</p>}
        </div>
      )}
      {children}
    </motion.div>
  );
}
