import { useEffect, useRef, useState } from "react";
import { usePremium } from "../hooks/usePremium";
import { useSiteConfig } from "../store/SiteConfigContext";
import { cn } from "../utils/cn";

export type AdVariant = "leaderboard" | "banner";

const SIZES: Record<AdVariant, { width: number; height: number }> = {
  leaderboard: { width: 728, height: 90 },
  banner: { width: 468, height: 60 },
};

/* invoke.js reads window.atOptions, therefore individual script loads must not overlap. */
let adQueue: Promise<void> = Promise.resolve();
const loadedSlots = new Set<string>();

function queueAd(variant: AdVariant, key: string, slotId: string, mount: HTMLElement) {
  let cancelled = false;
  adQueue = adQueue.then(() => new Promise<void>((resolve) => {
    if (cancelled || loadedSlots.has(slotId)) return resolve();
    loadedSlots.add(slotId);
    const size = SIZES[variant];
    (window as unknown as Record<string, unknown>).atOptions = { key, format: "iframe", ...size, params: {} };
    const script = document.createElement("script");
    script.src = `https://www.highperformanceformat.com/${key}/invoke.js`;
    script.async = true;
    script.dataset.adSlot = slotId;
    let finished = false;
    const done = () => {
      if (finished) return;
      finished = true;
      window.dispatchEvent(new CustomEvent("pv:ad-loaded", { detail: { variant, slotId } }));
      resolve();
    };
    script.onload = done;
    script.onerror = done;
    window.setTimeout(done, 5000);
    mount.appendChild(script);
  }));
  return () => { cancelled = true; };
}

interface Props {
  variant: AdVariant;
  className?: string;
  responsive?: boolean;
  label?: string;
  hideLabel?: boolean;
  /** Admin-configurable switch for a distinct placement. */
  slotId?: string;
}

/** Lazy, safe and configurable ad slot. Premium members never load third-party ad code. */
export default function AdUnit({ variant, className, responsive = true, label, hideLabel, slotId }: Props) {
  const mountRef = useRef<HTMLDivElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const generatedSlot = useRef(`pv-${variant}-${Math.random().toString(36).slice(2, 9)}`);
  const [visible, setVisible] = useState(false);
  const { premium } = usePremium();
  const { config } = useSiteConfig();
  const id = slotId || generatedSlot.current;
  const size = SIZES[variant];
  const key = variant === "leaderboard" ? config.ads.leaderboardKey : config.ads.bannerKey;
  const disabled = !config.ads.enabled || Boolean(config.ads.disabledSlots[id]);

  useEffect(() => {
    if (premium || disabled) return;
    const element = rootRef.current;
    if (!element || typeof IntersectionObserver === "undefined") {
      setVisible(true);
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) {
        setVisible(true);
        observer.disconnect();
      }
    }, { rootMargin: "200px 0px", threshold: 0 });
    observer.observe(element);
    return () => observer.disconnect();
  }, [disabled, premium]);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount || !visible || premium || disabled || !key) return;
    return queueAd(variant, key, id, mount);
  }, [disabled, id, key, premium, variant, visible]);

  if (premium || disabled) return null;
  return (
    <div ref={rootRef} className={cn("my-6 w-full", responsive && variant === "leaderboard" && "hidden md:block", className)} aria-label="advertisement">
      <div className="mx-auto w-fit max-w-full overflow-hidden">
        {!hideLabel && <p className="mb-1 text-center text-[10px] font-semibold uppercase tracking-[0.2em] text-slate-600">{label || "Advertisement · Ads support Play VAULT"}</p>}
        <div ref={mountRef} className="mx-auto flex items-center justify-center overflow-hidden rounded-lg border border-white/5 bg-slate-900/40" style={{ width: size.width, height: size.height, maxWidth: "100%" }}>
          {!visible && <span className="text-xs text-slate-600">Loading sponsored content…</span>}
        </div>
      </div>
    </div>
  );
}