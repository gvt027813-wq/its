/**
 * Play VAULT — Auto Game Seeder
 * Pulls 1000+ games from the GamePix public feed and upserts them
 * into MongoDB as VERIFIED games. Run with: npm run seed
 */
require('dotenv').config();
const mongoose = require('mongoose');
const Game = require('./models/Game');

const SID = '98R78';
const API = `https://games.gamepix.com/games?sid=${SID}&order=q&limit=1000`;

function normalizeCategory(raw = '') {
  const c = raw.toLowerCase();
  if (/action|fight|war|battle/.test(c)) return 'action';
  if (/puzzle|match|brain|logic/.test(c)) return 'puzzle';
  if (/rac|car|drive|drift|bike|moto/.test(c)) return 'racing';
  if (/sport|soccer|football|basket/.test(c)) return 'sports';
  if (/arcade|classic|retro/.test(c)) return 'arcade';
  if (/shoot|gun|sniper|zombie/.test(c)) return 'shooting';
  if (/adventure|rpg|quest|escape/.test(c)) return 'adventure';
  if (/strategy|tower|defense/.test(c)) return 'strategy';
  if (/board|card|chess/.test(c)) return 'board';
  return 'casual';
}

async function seed() {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/playvault');
  console.log('Connected. Fetching GamePix feed…');

  const res = await fetch(API);
  const json = await res.json();
  const items = json.data || [];
  console.log(`Fetched ${items.length} games. Upserting…`);

  let added = 0;
  for (const g of items) {
    if (!g.url || !g.thumbnailUrl) continue;
    await Game.updateOne(
      { title: g.title },
      {
        $set: {
          title: g.title,
          description: g.description || '',
          category: normalizeCategory(g.category),
          thumb: g.thumbnailUrl,
          url: g.url,
          source: 'GamePix',
          featured: !!g.featured,
          rating: g.rkScore ? Math.min(5, 3.6 + g.rkScore * 1.4) : 4.5,
          plays: Math.floor((g.rkScore || 0.5) * 990000),
          width: g.width,
          height: g.height,
          verified: true,
          verifiedAt: new Date(),
          verifiedBy: 'Auto-Seeder',
        },
      },
      { upsert: true }
    );
    added++;
  }

  console.log(`Done. ${added} games verified & saved.`);
  await mongoose.disconnect();
}

seed().catch((e) => {
  console.error('Seed failed:', e.message);
  process.exit(1);
});
