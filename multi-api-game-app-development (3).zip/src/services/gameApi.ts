import type { Game } from "../types";
import { normalizeCategory } from "../data/categories";
import { FALLBACK_GAMES } from "../data/fallbackGames";

// GamePix public Games API (CORS enabled, returns up to 1000 games).
// sid is a public syndication id used only for stat tracking.
const SID = "98R78";
const GAMEPIX_API = `https://games.gamepix.com/games?sid=${SID}`;

interface GamePixGame {
  id: string;
  title: string;
  description?: string;
  category?: string;
  categories?: string[];
  thumbnailUrl?: string;
  thumbnailUrl100?: string;
  url: string;
  width?: number;
  height?: number;
  featured?: boolean;
  rkScore?: number;
}

function mapGame(g: GamePixGame): Game {
  return {
    id: `gp-${g.id}`,
    title: g.title,
    description: g.description || "Play this exciting game instantly in your browser!",
    category: normalizeCategory(g.category || (g.categories && g.categories[0]) || ""),
    thumb: g.thumbnailUrl || g.thumbnailUrl100 || "",
    banner: g.thumbnailUrl,
    url: g.url,
    source: "GamePix",
    width: g.width,
    height: g.height,
    featured: !!g.featured,
    rating: g.rkScore ? Math.min(5, Math.max(3.5, 3.6 + (g.rkScore || 0.5) * 1.4)) : 4.2,
    plays: g.rkScore ? Math.floor((g.rkScore || 0.5) * 990000) : 500,
  };
}

async function fetchBatch(order: "q" | "d", limit: number, offset: number): Promise<Game[]> {
  try {
    const res = await fetch(`${GAMEPIX_API}&order=${order}&limit=${limit}&offset=${offset}`, {
      headers: { Accept: "application/json" },
    });
    if (!res.ok) throw new Error(`status ${res.status}`);
    const json = await res.json();
    const data: GamePixGame[] = json.data || [];
    return data.map(mapGame).filter((g) => g.url && g.thumb);
  } catch {
    return [];
  }
}

function dedupe(games: Game[]): Game[] {
  const seen = new Set<string>();
  const out: Game[] = [];
  for (const g of games) {
    const key = g.id;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(g);
  }
  return out;
}

/**
 * Loads a large catalog (1000+) by quality order, plus newest games,
 * merged with a curated set. Falls back to curated games if offline.
 */
export async function loadGames(): Promise<Game[]> {
  // Two ordered pulls give both "most played" and "newest" for variety.
  const [byQuality, byDate] = await Promise.all([
    fetchBatch("q", 1000, 0),
    fetchBatch("d", 1000, 0),
  ]);

  let all = dedupe([...byQuality, ...byDate]);

  if (all.length === 0) {
    return FALLBACK_GAMES;
  }

  all = dedupe([...FALLBACK_GAMES, ...all]);

  // Ensure a healthy set of featured highlights.
  let featuredCount = all.filter((g) => g.featured).length;
  if (featuredCount < 20) {
    for (const g of all) {
      if (featuredCount >= 30) break;
      if ((g.rating || 0) >= 4.6 && !g.featured) {
        g.featured = true;
        featuredCount++;
      }
    }
  }

  return all;
}
