/** Play VAULT secured API — © 2026 Vivek Trivedi. */
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const connectDB = require('./database/connection');
const games = require('./routes/games');
const { requestId, requireAuth, requireAdmin } = require('./middleware/security');

const app = express();
const allowedOrigins = (process.env.CLIENT_ORIGINS || 'https://playvault.gg,https://admin.playvault.gg,https://developers.playvault.gg').split(',').map((origin) => origin.trim());
app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin(origin, callback) { if (!origin || allowedOrigins.includes(origin)) return callback(null, true); return callback(new Error('CORS origin denied')); }, methods: ['GET', 'POST', 'PUT'], allowedHeaders: ['Content-Type', 'Authorization'] }));
app.use(express.json({ limit: '32kb', strict: true }));
app.use(requestId);
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many requests. Please try again later.' } }));
app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'Play VAULT API', requestId: req.requestId }));
app.get('/api/v1/games', games.getGames);
app.post('/api/v1/games', requireAuth, games.addGame);
app.put('/api/v1/games/:id/verify', requireAuth, requireAdmin, games.verifyGame);
app.use((error, req, res, next) => { if (error) { console.error('api.error', req.requestId, error.message); return res.status(error.message === 'CORS origin denied' ? 403 : 500).json({ error: 'Request could not be completed', requestId: req.requestId }); } return next(); });
app.use((req, res) => res.status(404).json({ error: 'Endpoint not found', requestId: req.requestId }));
const PORT = Number(process.env.PORT || 5000);
connectDB().then(() => app.listen(PORT, () => console.log(`Play VAULT secured API listening on ${PORT}`))).catch((error) => { console.error('Startup failed', error.message); process.exit(1); });