import { useMemo } from "react";
import { motion } from "framer-motion";
import type { Game } from "../../types";
import GameCard from "../GameCard";
import { useGames } from "../../store/GameContext";
import { InFeedAd } from "../AdPlacements";
import { useSiteConfig } from "../../store/SiteConfigContext";

/* ─────────────────────────────────────────────────────────────────
 * <GameGrid /> with SMART IN-FEED AD INJECTION
 *
 * After every AD_INTERVAL games, an <InFeedAd /> is automatically
 * injected, giving us 20+ ad slots across the site without manual
 * placement on each page.
 *
 * Strategy:
 *   - Start injecting after AD_START (first 4 games stay clean)
 *   - Then every AD_INTERVAL games
 *   - Respects Premium users (InFeedAd internally returns null)
 *   - Maintains grid alignment (InFeedAd spans all columns)
 * ──────────────────────────────────────────────────────────────── */
const AD_START = 4;     // skip first 4 slots
const AD_INTERVAL = 8;  // every 8 games → one ad

interface Props {
  games: Game[];
  emptyText?: string;
  limit?: number;
  /** Enable in-feed ads (default: true) */
  withAds?: boolean;
}

export default function GameGrid({ games, emptyText = "No games found.", limit, withAds = true }: Props) {
  const { isFavorite, toggleFavorite, addRecent } = useGames();
  const { config } = useSiteConfig();
  const list = limit ? games.slice(0, limit) : games;

  // Build the interleaved list: [game, game, ..., Ad, game, ...]
  const mixed = useMemo(() => {
    if (!withAds) return list.map((g) => ({ kind: "game" as const, g }));
    const out: Array<{ kind: "game"; g: Game } | { kind: "ad"; i: number }> = [];
    let adCount = 0;
    list.forEach((g, i) => {
      out.push({ kind: "game", g });
      if (adCount < config.ads.maxInFeedAds && i >= AD_START && (i + 1 - AD_START) % AD_INTERVAL === 0) {
        out.push({ kind: "ad", i });
        adCount++;
      }
    });
    return out;
  }, [config.ads.maxInFeedAds, list, withAds]);

  if (list.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
        <span className="text-5xl">🎯</span>
        <p className="text-slate-400">{emptyText}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-7 xl:grid-cols-8">
      {mixed.map((item, idx) => {
        if (item.kind === "ad") return <InFeedAd key={`ad-${idx}`} slotId={`game-grid-${item.i}`} />;
        const g = item.g;
        return (
          <motion.div
            key={g.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, delay: Math.min(idx * 0.012, 0.4) }}
          >
            <GameCard
              game={g}
              onPlay={(game) => {
                addRecent(game.id);
              }}
              isFavorite={isFavorite(g.id)}
              onToggleFavorite={toggleFavorite}
            />
          </motion.div>
        );
      })}
    </div>
  );
}
