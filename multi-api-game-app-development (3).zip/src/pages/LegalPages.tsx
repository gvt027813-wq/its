import PageShell from "../components/ui/PageShell";
import { Section } from "../components/ui/Common";

const OWNER_EMAIL = "vivektrivedi236@gmail.com";

function Legal({ title, icon, intro, sections }: { title: string; icon: string; intro: string; sections: { t: string; c: string }[] }) {
  return (
    <PageShell title={title} subtitle="Last updated: January 2026" icon={icon} maxWidth="max-w-3xl">
      <p className="mb-6 text-sm leading-relaxed text-slate-300">{intro}</p>
      {sections.map((s, i) => (
        <Section key={i} title={`${i + 1}. ${s.t}`}><p>{s.c}</p></Section>
      ))}
      <p className="mt-8 text-xs text-slate-500">
        If you have questions about this document, contact the owner — Vivek Trivedi at {OWNER_EMAIL}.
      </p>
    </PageShell>
  );
}

export function Privacy() {
  return <Legal title="Privacy Policy" icon="🔒" intro="Your privacy matters to us. This policy explains what data Play VAULT collects and how we use it." sections={[
    { t: "Information We Collect", c: "We store your favorites, play history, and preferences locally on your device and optionally sync them to our secure Firebase database. We do not sell personal data." },
    { t: "Cookies", c: "We use cookies and local storage to remember your settings and improve your experience." },
    { t: "Third-Party Games", c: "Games are hosted by third-party providers (e.g. GamePix) who may have their own privacy practices." },
    { t: "Data Security", c: "We use industry-standard measures (Firebase Security Rules, HTTPS) to protect any data we process." },
    { t: "Your Rights", c: "You can clear all local data anytime from the Settings page, and request deletion by emailing the owner." },
  ]} />;
}

export function Terms() {
  return <Legal title="Terms of Service" icon="📜" intro="By using Play VAULT, you agree to these terms." sections={[
    { t: "Acceptable Use", c: "Use Play VAULT for personal, non-commercial entertainment. Do not attempt to disrupt the service." },
    { t: "Content Ownership", c: "All games belong to their respective creators. Play VAULT aggregates and links to them. The Play VAULT platform, branding and code are © Vivek Trivedi." },
    { t: "Accounts", c: "You are responsible for activity under your account and for keeping credentials secure." },
    { t: "Disclaimer", c: "The service is provided 'as is' without warranties of any kind." },
    { t: "Changes", c: "We may update these terms; continued use means acceptance of changes." },
  ]} />;
}

export function Cookies() {
  return <Legal title="Cookie Policy" icon="🍪" intro="This policy explains how Play VAULT uses cookies and similar technologies." sections={[
    { t: "What Are Cookies", c: "Small files stored on your device that help websites remember information." },
    { t: "How We Use Them", c: "To save preferences, favorites, and analyze usage to improve the site." },
    { t: "Managing Cookies", c: "You can control cookies through your browser settings at any time." },
  ]} />;
}

export function DMCA() {
  return <Legal title="DMCA Policy" icon="⚖️" intro="We respect intellectual property rights and respond to valid takedown notices." sections={[
    { t: "Filing a Notice", c: `Send a detailed notice to ${OWNER_EMAIL} identifying the copyrighted work and its location.` },
    { t: "Counter-Notices", c: "If you believe content was removed in error, you may submit a counter-notice." },
    { t: "Repeat Infringers", c: "We terminate access for repeat infringers where appropriate." },
  ]} />;
}

export function CommunityGuidelines() {
  return <Legal title="Community Guidelines" icon="🤗" intro="Keep Play VAULT fun and welcoming for everyone." sections={[
    { t: "Be Respectful", c: "Treat other players with kindness. No harassment, hate speech, or bullying." },
    { t: "Play Fair", c: "No cheating, exploiting, or manipulating leaderboards." },
    { t: "Keep It Clean", c: "No inappropriate content in usernames, chat, or feedback." },
    { t: "Report Issues", c: "Use the feedback page to report violations." },
  ]} />;
}

export function Disclaimer() {
  return <Legal title="Disclaimer" icon="⚠️" intro="Please read this disclaimer carefully before using Play VAULT." sections={[
    { t: "External Content", c: "Games are provided by third parties. We are not responsible for their content or availability." },
    { t: "No Warranty", c: "We make no guarantees about uptime, accuracy, or fitness for a particular purpose." },
    { t: "Limitation of Liability", c: "Play VAULT is not liable for any damages arising from use of the service." },
  ]} />;
}

export function RefundPolicy() {
  return <Legal title="Refund Policy" icon="💸" intro="This policy covers refunds for Premium subscriptions and coin purchases." sections={[
    { t: "Subscriptions", c: "Premium subscriptions can be cancelled anytime; refunds for unused periods are considered case-by-case." },
    { t: "Coin Purchases", c: "Virtual coins are non-refundable once credited to your account." },
    { t: "How to Request", c: `Contact ${OWNER_EMAIL} within 14 days of purchase.` },
  ]} />;
}
