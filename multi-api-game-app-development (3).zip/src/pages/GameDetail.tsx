import { useMemo, useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { useGames } from "../store/GameContext";
import GameRow from "../components/ui/GameRow";
import PageShell from "../components/ui/PageShell";
import { Loader, Btn } from "../components/ui/Common";
import { cn } from "../utils/cn";
import SEO from "../components/SEO";
import AdUnit from "../components/AdUnit";
import { StickyAd } from "../components/AdPlacements";
import { categoryPath, gameIdFromSlug, gamePath } from "../utils/gameUrl";
import { gameDescription, gameFaq, gameGuide, gameSchemas } from "../utils/gameSeo";

export default function GameDetail() {
  const { slug = "" } = useParams();
  const gameId = gameIdFromSlug(slug);
  const { getGame, games, loading, isFavorite, toggleFavorite, addRecent } = useGames();
  const [playing, setPlaying] = useState(false);
  const [frameLoaded, setFrameLoaded] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);

  const game = gameId ? getGame(gameId) : undefined;

  useEffect(() => {
    if (game) addRecent(game.id);
    setPlaying(false);
    setFrameLoaded(false);
  }, [game, addRecent]);

  const related = useMemo(() => {
    if (!game) return [];
    return games.filter((g) => g.category === game.category && g.id !== game.id).slice(0, 14);
  }, [game, games]);

  const alsoLike = useMemo(() => [...games].sort((a, b) => (b.plays || 0) - (a.plays || 0)).filter((g) => g.id !== game?.id).slice(0, 14), [games, game]);
  const guide = game ? gameGuide(game) : null;

  if (loading) return <PageShell><Loader label="Loading game…" /></PageShell>;

  if (!game) {
    return (
      <PageShell title="Game Not Found" icon="😕">
        <p className="text-slate-400">This game could not be found.</p>
        <Link to="/games" className="mt-4 inline-block"><Btn>Browse All Games</Btn></Link>
      </PageShell>
    );
  }

  return (
    <PageShell maxWidth="max-w-6xl">
      <SEO
        title={`Play ${game.title} Free Online`}
        description={gameDescription(game)}
        keywords={`${game.title}, play ${game.title} online, free ${game.category} games, ${game.category} browser games`}
        path={gamePath(game)}
        image={game.thumb}
        type="video.other"
        structuredData={gameSchemas(game)}
      />
      <nav className="mb-4 flex items-center gap-1 text-xs text-slate-400">
        <Link to="/" className="hover:text-white">Home</Link>
        <span>/</span>
        <Link to={categoryPath(game.category)} className="capitalize hover:text-white">{game.category} games</Link>
        <span>/</span>
        <span className="text-slate-300">{game.title}</span>
      </nav>

      {/* Player */}
      <div className={cn("relative overflow-hidden rounded-2xl bg-black ring-1 ring-white/10", fullscreen ? "fixed inset-0 z-50 rounded-none" : "aspect-video w-full")}>
        {!playing ? (
          <button onClick={() => setPlaying(true)} className="group relative h-full w-full">
            <img src={game.thumb} alt={`Play ${game.title} online`} className="h-full w-full object-cover opacity-60" width={1280} height={720} />
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-slate-950/40">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-white shadow-2xl transition-transform group-hover:scale-110">
                <svg className="ml-1.5 h-9 w-9 text-indigo-700" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
              </div>
              <span className="rounded-full bg-indigo-600 px-6 py-2 text-sm font-bold text-white">Play {game.title}</span>
            </div>
          </button>
        ) : (
          <>
            {!frameLoaded && (
              <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
                <div className="h-12 w-12 animate-spin rounded-full border-4 border-slate-700 border-t-indigo-500" />
              </div>
            )}
            <iframe
              src={game.url}
              title={game.title}
              className="h-full w-full"
              allow="fullscreen; autoplay; gamepad; microphone; camera"
              allowFullScreen
              onLoad={() => setFrameLoaded(true)}
            />
            <button
              onClick={() => setFullscreen((f) => !f)}
              className="absolute right-3 top-3 z-10 flex h-10 w-10 items-center justify-center rounded-lg bg-slate-900/80 text-white backdrop-blur transition hover:bg-slate-800"
              title="Fullscreen"
            >
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3m8 0h3a2 2 0 0 0 2-2v-3" />
              </svg>
            </button>
          </>
        )}
      </div>

      {/* Info bar */}
      <div className="mt-5 flex flex-col gap-4 rounded-2xl bg-slate-800/60 p-5 ring-1 ring-white/5 sm:flex-row sm:items-center">
        <img src={game.thumb} alt="" className="h-16 w-16 rounded-xl object-cover" width={64} height={64} />
        <div className="min-w-0 flex-1">
          <h1 className="text-xl font-extrabold text-white">{game.title}</h1>
          <div className="mt-1 flex flex-wrap items-center gap-3 text-sm text-slate-400">
            <span className="flex items-center gap-1"><span className="text-amber-400">★</span>{game.rating?.toFixed(1)}</span>
            <span className="capitalize">🗂️ {game.category}</span>
            <span title="Provider popularity signal">📈 Popular game</span>
            <span>🏷️ {game.source}</span>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => toggleFavorite(game.id)}
            className={cn("flex h-11 items-center gap-2 rounded-xl px-4 text-sm font-bold transition", isFavorite(game.id) ? "bg-rose-600 text-white" : "bg-slate-700 text-slate-200 hover:bg-slate-600")}
          >
            <svg className="h-5 w-5" fill={isFavorite(game.id) ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z" />
            </svg>
            {isFavorite(game.id) ? "Saved" : "Save"}
          </button>
          {!playing && <Btn onClick={() => setPlaying(true)}>▶ Play</Btn>}
        </div>
      </div>

      {/* Description */}
      <div className="mt-5 rounded-2xl bg-slate-800/60 p-5 ring-1 ring-white/5">
        <h2 className="mb-2 text-lg font-bold text-white">About {game.title}</h2>
        <p className="text-sm leading-relaxed text-slate-300">{game.description || gameDescription(game)}</p>
        <div className="mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
          <div className="rounded-lg bg-slate-900/60 p-3"><p className="text-slate-500">Platform</p><p className="font-semibold text-white">Browser</p></div>
          <div className="rounded-lg bg-slate-900/60 p-3"><p className="text-slate-500">Controls</p><p className="font-semibold text-white">Mouse / Touch</p></div>
          <div className="rounded-lg bg-slate-900/60 p-3"><p className="text-slate-500">Category</p><p className="font-semibold capitalize text-white">{game.category}</p></div>
          <div className="rounded-lg bg-slate-900/60 p-3"><p className="text-slate-500">Price</p><p className="font-semibold text-emerald-400">Free</p></div>
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <section className="rounded-2xl bg-slate-800/60 p-5 ring-1 ring-white/5">
          <h2 className="text-lg font-bold text-white">How to Play {game.title}</h2>
          <p className="mt-2 text-sm leading-relaxed text-slate-300">Open the player above, select Play, and use the on-screen prompts. {guide?.controls}</p>
          <h3 className="mt-4 text-sm font-bold text-amber-300">Quick Tips</h3>
          <ul className="mt-2 space-y-2 text-sm text-slate-300">
            {guide?.tips.map((tip) => <li key={tip} className="flex gap-2"><span className="text-amber-400">•</span>{tip}</li>)}
          </ul>
          <h3 className="mt-4 text-sm font-bold text-amber-300">Game Features</h3>
          <ul className="mt-2 space-y-1 text-sm text-slate-300">{guide?.features.map((feature) => <li key={feature}>✓ {feature}</li>)}</ul>
        </section>
        <section className="rounded-2xl bg-slate-800/60 p-5 ring-1 ring-white/5">
          <h2 className="text-lg font-bold text-white">{game.title} FAQ</h2>
          <div className="mt-3 space-y-2">
            {gameFaq(game).map((item) => (
              <details key={item.question} className="rounded-lg bg-slate-900/60 px-3 py-2">
                <summary className="cursor-pointer text-sm font-semibold text-white">{item.question}</summary>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{item.answer}</p>
              </details>
            ))}
          </div>
        </section>
      </div>

      <AdUnit variant="banner" className="mt-6" slotId="game-detail-info" />

      <div className="mt-2">
        <GameRow title="More Like This" icon="🎯" games={related} seeAllTo={categoryPath(game.category)} />
        <AdUnit variant="leaderboard" slotId="game-detail-related" />
        <GameRow title="You May Also Like" icon="✨" games={alsoLike} seeAllTo="/trending" />
      </div>
      <StickyAd />
    </PageShell>
  );
}
