# Play VAULT SEO Implementation

## What Is Implemented

- Canonical, readable routes:
  - `/games`
  - `/games/action`
  - `/games/racing/moto-x3m-spooky-land--gp-7ms9m`
- Legacy `/game/:id` and `/category/:id` URLs issue in-app redirects to the new canonical URLs.
- One crawlable internal `<a>` link per game card, plus category and related-game links.
- Real `document.head` metadata management via `src/components/SEO.tsx`: title, description, canonical, robots, Open Graph and Twitter cards.
- Unique game `VideoGame`, `FAQPage`, and `BreadcrumbList` JSON-LD.
- Category `CollectionPage` JSON-LD, plus `WebSite` search schema.
- Unique Home, browse, category, game, blog, article, FAQ, trending, new and top-rated metadata.
- `public/sitemap.xml`, `public/robots.txt`, `public/_redirects`, and `netlify.toml` for crawlable direct routes on Netlify.
- `scripts/generate-sitemap.mjs` generates up to 1,000 canonical game URLs from the game catalog.
- A static no-JavaScript homepage fallback in `index.html` so category links and core copy remain visible without app rendering.
- `netlify/edge-functions/seo-prerender.ts` serves full equivalent HTML for recognised search/social crawlers on `/games/*` routes: title, description, canonical, Open Graph, `VideoGame`, breadcrumb and FAQ JSON-LD, visible game guide, FAQ, category links and game cards.

## Domain Setup

The temporary canonical base is `https://vaultplays.netlify.app`.

Before production, choose one permanent domain such as `https://vaultplays.com` and update:

1. `<html data-site-url="...">` in `index.html`.
2. `public/robots.txt` sitemap host.
3. Sitemap with:

```bash
SITE_URL=https://vaultplays.com node scripts/generate-sitemap.mjs
```

4. In Netlify, make the chosen custom domain the **primary domain** and configure 301 redirects from all aliases (including `vaultplays.netlify.app`) to it.

## Before Every Catalog Release

```bash
SITE_URL=https://vaultplays.com node scripts/generate-sitemap.mjs
npm run build
```

The sitemap script does not invent content; it only generates URLs for valid games returned by the feed. Keep game descriptions, controls, tips, and FAQs useful before adding pages to the sitemap.

## Google Search Console Checklist

1. Add a Domain property for the final custom domain.
2. Complete DNS verification.
3. Submit `https://vaultplays.com/sitemap.xml`.
4. Use URL Inspection on `/`, `/games/action`, and several individual game URLs.
5. Check Page Indexing weekly for excluded, duplicate, and soft-404 URLs.
6. Use the Performance report to update pages with impressions but low CTR (rewrite title/description) or positions 8-30 (improve useful on-page content and internal links).

## Content Rules

- Do not publish empty iframe-only game pages.
- Keep the visible `About`, `How to Play`, controls, tips, FAQ, and related-games areas useful and specific.
- Do not create large batches of AI articles or keyword-stuffed copy simply to rank.
- Do not add fake ratings, reviews, download counts, or first-party play counts to structured data.

## Rendering Strategy

Google can render JavaScript, but server-rendered or pre-rendered HTML is stronger for a very large game catalog. On Netlify, the included Edge function provides dynamic prerendering for crawlers while normal players retain the React experience. Its HTML intentionally mirrors the visible game/category content rather than using keyword-only crawler pages.

For the next SEO scale step, move individual game/category routes to true static generation or SSR (for example Astro or Next.js) while preserving the canonical URL structure above. This removes crawler user-agent detection and lets every visitor receive server-rendered HTML.