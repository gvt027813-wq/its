import type { Game } from "../../types";
import GameCard from "../GameCard";
import { useGames } from "../../store/GameContext";
import { Link } from "react-router-dom";

interface Props {
  title: string;
  icon?: string;
  games: Game[];
  seeAllTo?: string;
}

export default function GameRow({ title, icon, games, seeAllTo }: Props) {
  const { isFavorite, toggleFavorite, addRecent } = useGames();
  if (games.length === 0) return null;

  return (
    <section className="mb-8">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-lg font-extrabold text-white sm:text-xl">
          {icon && <span>{icon}</span>}
          {title}
        </h2>
        {seeAllTo && (
          <Link to={seeAllTo} className="text-sm font-semibold text-indigo-400 transition hover:text-indigo-300">
            See all →
          </Link>
        )}
      </div>
      <div className="-mx-1 flex gap-3 overflow-x-auto px-1 pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {games.map((g) => (
          <div key={g.id} className="w-32 shrink-0 sm:w-40">
            <GameCard
              game={g}
              onPlay={(game) => {
                addRecent(game.id);
              }}
              isFavorite={isFavorite(g.id)}
              onToggleFavorite={toggleFavorite}
            />
          </div>
        ))}
      </div>
    </section>
  );
}
