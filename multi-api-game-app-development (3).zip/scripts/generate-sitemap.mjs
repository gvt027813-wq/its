/**
 * Generates indexable category and game URLs from the live GamePix catalog.
 * Usage: SITE_URL=https://vaultplays.com node scripts/generate-sitemap.mjs
 * Run before deployment whenever the catalog changes.
 */
import { writeFile } from "node:fs/promises";

const siteUrl = (process.env.SITE_URL || "https://vaultplays.netlify.app").replace(/\/$/, "");
const sid = process.env.GAMEPIX_SID || "98R78";
const feedUrl = `https://games.gamepix.com/games?sid=${encodeURIComponent(sid)}&order=q&limit=1000`;
const categories = ["action", "puzzle", "racing", "sports", "arcade", "shooting", "adventure", "girls", "strategy", "board", "casual", "io"];
const staticPaths = ["/", "/games", "/trending", "/new", "/top-rated", "/about", "/blog", "/contact", "/faq"];

function slugify(value) {
  return String(value || "game").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "game";
}

function normalizeCategory(raw = "") {
  const c = String(raw).toLowerCase();
  if (/action|fight|war|battle/.test(c)) return "action";
  if (/puzzle|match|brain|logic|blocks/.test(c)) return "puzzle";
  if (/rac|car|drive|drift|bike|moto/.test(c)) return "racing";
  if (/sport|soccer|football|basket|golf|pool/.test(c)) return "sports";
  if (/arcade|classic|retro/.test(c)) return "arcade";
  if (/shoot|gun|sniper|zombie/.test(c)) return "shooting";
  if (/adventure|rpg|quest|escape/.test(c)) return "adventure";
  if (/girl|dress|makeup|fashion|beauty/.test(c)) return "girls";
  if (/strategy|tower|defense|manage/.test(c)) return "strategy";
  if (/board|card|chess|checker|domino/.test(c)) return "board";
  if (/io|multiplayer/.test(c)) return "io";
  return "casual";
}

function xmlEscape(value) {
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function urlNode(path, priority) {
  return `  <url><loc>${xmlEscape(`${siteUrl}${path}`)}</loc><changefreq>weekly</changefreq><priority>${priority}</priority></url>`;
}

const response = await fetch(feedUrl, { headers: { Accept: "application/json" } });
if (!response.ok) throw new Error(`Game feed failed with ${response.status}`);
const feed = await response.json();
const games = Array.isArray(feed.data) ? feed.data : [];
const unique = new Set();
const gameNodes = [];

for (const game of games) {
  if (!game?.id || !game?.title || !game?.url) continue;
  const category = normalizeCategory(game.category || game.categories?.[0]);
  const id = `gp-${String(game.id).toLowerCase()}`;
  const path = `/games/${encodeURIComponent(category)}/${slugify(game.title)}--${encodeURIComponent(id)}`;
  if (unique.has(path)) continue;
  unique.add(path);
  gameNodes.push(urlNode(path, "0.7"));
}

const lines = [
  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
  "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">",
  ...staticPaths.map((path) => urlNode(path, path === "/" ? "1.0" : "0.8")),
  ...categories.map((category) => urlNode(`/games/${category}`, "0.8")),
  ...gameNodes,
  "</urlset>",
  "",
];

await writeFile(new URL("../public/sitemap.xml", import.meta.url), lines.join("\n"), "utf8");
console.log(`Generated ${gameNodes.length} game URLs for ${siteUrl}/sitemap.xml`);