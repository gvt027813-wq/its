import { useState } from "react";
import { Link } from "react-router-dom";
import PageShell from "../components/ui/PageShell";
import { Card, Btn, StatCard, Badge } from "../components/ui/Common";
import { useGames } from "../store/GameContext";
import { usePremium } from "../hooks/usePremium";
import AdUnit from "../components/AdUnit";
import { SponsoredBanner } from "../components/AdPlacements";

export function Profile() {
  const { favorites, recent, games } = useGames();
  const played = recent.length;
  const level = Math.max(1, Math.floor(played / 3) + 1);
  const xp = (played * 40) % 100;

  return (
    <PageShell maxWidth="max-w-4xl">
      <div className="relative mb-6 overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 p-6 sm:p-8">
        <div className="flex flex-col items-center gap-4 text-center sm:flex-row sm:text-left">
          <div className="flex h-24 w-24 items-center justify-center rounded-full bg-white/20 text-4xl font-black text-white ring-4 ring-white/30">P</div>
          <div className="flex-1">
            <h1 className="text-2xl font-extrabold text-white">Player One</h1>
            <p className="text-indigo-100">Play VAULT Member · Level {level} Gamer</p>
            <div className="mt-3 max-w-xs">
              <div className="mb-1 flex justify-between text-xs text-indigo-100"><span>XP</span><span>{xp}/100</span></div>
              <div className="h-2 overflow-hidden rounded-full bg-white/20"><div className="h-full bg-white" style={{ width: `${xp}%` }} /></div>
            </div>
          </div>
          <Link to="/settings"><Btn variant="ghost">Edit Profile</Btn></Link>
        </div>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon="🎮" label="Games Played" value={`${played}`} />
        <StatCard icon="❤️" label="Favorites" value={`${favorites.length}`} />
        <StatCard icon="🏆" label="Level" value={`${level}`} />
        <StatCard icon="💰" label="Coins" value={`${played * 50 + 200}`} />
      </div>

      <SponsoredBanner position={1} className="mb-6" />
      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <h3 className="mb-3 font-bold text-white">Quick Links</h3>
          <div className="space-y-2 text-sm">
            <Link to="/favorites" className="block rounded-lg bg-slate-900/60 px-3 py-2 hover:bg-slate-900">❤️ My Favorites ({favorites.length})</Link>
            <Link to="/recent" className="block rounded-lg bg-slate-900/60 px-3 py-2 hover:bg-slate-900">🕒 Play History</Link>
            <Link to="/achievements" className="block rounded-lg bg-slate-900/60 px-3 py-2 hover:bg-slate-900">🎖️ Achievements</Link>
            <Link to="/wallet" className="block rounded-lg bg-slate-900/60 px-3 py-2 hover:bg-slate-900">💰 Wallet</Link>
          </div>
        </Card>
        <Card>
          <h3 className="mb-3 font-bold text-white">Membership</h3>
          <div className="flex items-center gap-2"><Badge color="bg-amber-500/20 text-amber-300">FREE PLAN</Badge></div>
          <p className="mt-3 text-sm text-slate-400">Upgrade to Premium for ad-free play, exclusive games, and bonus coins.</p>
          <Link to="/premium" className="mt-4 inline-block"><Btn>👑 Go Premium</Btn></Link>
        </Card>
      </div>
      <p className="mt-4 text-center text-xs text-slate-500">Total library: {games.length.toLocaleString()} games available</p>
    </PageShell>
  );
}

export function Settings() {
  const [dark, setDark] = useState(true);
  const [sound, setSound] = useState(true);
  const [notif, setNotif] = useState(true);
  const [autoplay, setAutoplay] = useState(false);

  const Toggle = ({ on, set, label, desc }: { on: boolean; set: (v: boolean) => void; label: string; desc: string }) => (
    <div className="flex items-center justify-between rounded-xl bg-slate-900/60 px-4 py-3">
      <div><p className="text-sm font-semibold text-white">{label}</p><p className="text-xs text-slate-500">{desc}</p></div>
      <button onClick={() => set(!on)} className={`relative h-6 w-11 rounded-full transition ${on ? "bg-indigo-600" : "bg-slate-600"}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition ${on ? "left-[22px]" : "left-0.5"}`} />
      </button>
    </div>
  );

  return (
    <PageShell title="Settings" subtitle="Customize your Play VAULT experience" icon="⚙️" maxWidth="max-w-2xl">
      <AdUnit variant="leaderboard" className="mb-4 mt-0" slotId="settings-top" />
      <div className="space-y-6">
        <Card>
          <h3 className="mb-3 font-bold text-white">Preferences</h3>
          <div className="space-y-3">
            <Toggle on={dark} set={setDark} label="Dark Mode" desc="Use the dark arcade theme" />
            <Toggle on={sound} set={setSound} label="Sound Effects" desc="Play UI sounds" />
            <Toggle on={notif} set={setNotif} label="Notifications" desc="Daily challenge reminders" />
            <Toggle on={autoplay} set={setAutoplay} label="Autoplay Games" desc="Start games automatically" />
          </div>
        </Card>
        <Card>
          <h3 className="mb-3 font-bold text-white">Account</h3>
          <div className="space-y-2 text-sm">
            <input placeholder="Display name" defaultValue="Player One" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-white outline-none focus:border-indigo-500" />
            <input placeholder="Email" defaultValue="player@playvault.gg" className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-white outline-none focus:border-indigo-500" />
          </div>
          <div className="mt-4 flex gap-2"><Btn>Save Changes</Btn><Btn variant="outline">Reset</Btn></div>
        </Card>
        <Card>
          <h3 className="mb-2 font-bold text-white">Data</h3>
          <p className="mb-3 text-xs text-slate-500">Clear your saved favorites and history from this device.</p>
          <Btn variant="outline" onClick={() => { localStorage.clear(); location.reload(); }}>Clear Local Data</Btn>
        </Card>
      </div>
    </PageShell>
  );
}

export function Wallet() {
  const { recent } = useGames();
  const coins = recent.length * 50 + 200;
  const txns = [
    { d: "Daily login bonus", a: "+50", t: "Today" },
    { d: "Played 3 games", a: "+30", t: "Today" },
    { d: "Achievement unlocked", a: "+100", t: "Yesterday" },
    { d: "Redeemed avatar", a: "-80", t: "2 days ago" },
    { d: "Weekly streak", a: "+150", t: "3 days ago" },
  ];
  return (
    <PageShell title="Wallet & Coins" subtitle="Earn coins by playing and redeem cool rewards" icon="💰" maxWidth="max-w-2xl">
      <AdUnit variant="leaderboard" className="mb-4 mt-0" slotId="wallet-top" />
      <div className="mb-6 rounded-3xl bg-gradient-to-br from-amber-500 to-orange-600 p-6 text-center">
        <p className="text-sm font-semibold text-amber-100">Your Balance</p>
        <p className="text-5xl font-black text-white">🪙 {coins.toLocaleString()}</p>
        <div className="mt-4 flex justify-center gap-2">
          <Link to="/rewards"><Btn variant="ghost">Redeem</Btn></Link>
          <Link to="/premium"><Btn variant="ghost">Buy Coins</Btn></Link>
        </div>
      </div>
      <Card>
        <h3 className="mb-3 font-bold text-white">Recent Transactions</h3>
        <div className="space-y-2">
          {txns.map((t, i) => (
            <div key={i} className="flex items-center justify-between rounded-lg bg-slate-900/60 px-3 py-2 text-sm">
              <div><p className="text-white">{t.d}</p><p className="text-xs text-slate-500">{t.t}</p></div>
              <span className={t.a.startsWith("+") ? "font-bold text-emerald-400" : "font-bold text-rose-400"}>{t.a}</span>
            </div>
          ))}
        </div>
      </Card>
    </PageShell>
  );
}

export function Rewards() {
  const items = [
    { icon: "🎨", name: "Custom Avatar", cost: 80 },
    { icon: "🏷️", name: "Name Badge", cost: 120 },
    { icon: "🚫", name: "Ad-Free Day", cost: 200 },
    { icon: "🎁", name: "Mystery Box", cost: 300 },
    { icon: "👑", name: "VIP 1 Week", cost: 500 },
    { icon: "💎", name: "Legend Frame", cost: 1000 },
  ];
  return (
    <PageShell title="Rewards Store" subtitle="Spend your coins on exclusive perks" icon="🎁" maxWidth="max-w-4xl">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {items.map((it) => (
          <Card key={it.name} className="text-center">
            <div className="text-4xl">{it.icon}</div>
            <p className="mt-2 font-bold text-white">{it.name}</p>
            <p className="mb-3 text-sm text-amber-400">🪙 {it.cost}</p>
            <Btn className="w-full">Redeem</Btn>
          </Card>
        ))}
      </div>
    </PageShell>
  );
}

export function Premium() {
  const { premium, activate, deactivate } = usePremium();
  const plans = [
    { id: "free", name: "Free", price: "$0", features: ["1000+ games", "Save favorites", "With ads"], highlight: false },
    { id: "premium", name: "Premium", price: "$4.99/mo", features: ["Everything in Free", "Ad-free play", "Exclusive games", "500 bonus coins/mo", "Priority support"], highlight: true },
    { id: "family", name: "Family", price: "$9.99/mo", features: ["Everything in Premium", "Up to 5 accounts", "Parental controls", "1500 bonus coins/mo"], highlight: false },
  ];
  return (
    <PageShell title="Play VAULT Premium" subtitle="Play more, pay less, no interruptions" icon="👑" maxWidth="max-w-4xl">
      {premium && (
        <div className="mb-6 flex items-center gap-3 rounded-2xl bg-emerald-500/15 p-4 ring-1 ring-emerald-400/30">
          <span className="text-2xl">👑</span>
          <div className="flex-1">
            <p className="font-bold text-emerald-300">Premium Active — All Ads Removed</p>
            <p className="text-xs text-emerald-200/70">Enjoy an uninterrupted Play VAULT experience.</p>
          </div>
          <Btn variant="outline" onClick={deactivate}>Switch to Free</Btn>
        </div>
      )}
      <div className="grid gap-4 md:grid-cols-3">
        {plans.map((p) => (
          <div key={p.name} className={`rounded-2xl p-6 ring-1 ${p.highlight ? "bg-gradient-to-br from-indigo-600 to-violet-700 ring-indigo-400" : "bg-slate-800/60 ring-white/5"}`}>
            {p.highlight && <Badge color="bg-amber-400 text-amber-950">MOST POPULAR</Badge>}
            <h3 className="mt-2 text-xl font-extrabold text-white">{p.name}</h3>
            <p className="text-3xl font-black text-white">{p.price}</p>
            <ul className="my-4 space-y-2 text-sm text-slate-200">
              {p.features.map((f) => <li key={f} className="flex items-center gap-2"><span className="text-emerald-400">✓</span>{f}</li>)}
            </ul>
            <Btn
              variant={p.highlight ? "ghost" : "outline"}
              className="w-full"
              onClick={() => (p.id === "free" ? deactivate() : activate())}
            >
              {premium && p.id !== "free" ? "✓ Active" : p.id === "free" ? (premium ? "Downgrade" : "Current Plan") : "Activate Now"}
            </Btn>
          </div>
        ))}
      </div>
      <p className="mt-4 text-center text-xs text-slate-500">
        Demo mode: activation is instant on this device. Billing by Play VAULT · Vivek Trivedi (vivektrivedi236@gmail.com).
      </p>
    </PageShell>
  );
}

export function ProfileAdSlot() {
  return (
    <SponsoredBanner position={3} className="mb-6" />
  );
}

export function Achievements() {
  const { recent, favorites } = useGames();
  const list = [
    { icon: "🎮", name: "First Game", desc: "Play your first game", done: recent.length >= 1 },
    { icon: "🔥", name: "On Fire", desc: "Play 5 games", done: recent.length >= 5 },
    { icon: "❤️", name: "Collector", desc: "Save 3 favorites", done: favorites.length >= 3 },
    { icon: "⭐", name: "Explorer", desc: "Play 10 games", done: recent.length >= 10 },
    { icon: "🏆", name: "Veteran", desc: "Play 20 games", done: recent.length >= 20 },
    { icon: "💎", name: "Legend", desc: "Save 10 favorites", done: favorites.length >= 10 },
  ];
  const unlocked = list.filter((a) => a.done).length;
  return (
    <PageShell title="Achievements" subtitle={`${unlocked} of ${list.length} unlocked`} icon="🎖️" maxWidth="max-w-3xl">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {list.map((a) => (
          <div key={a.name} className={`flex items-center gap-4 rounded-2xl p-4 ring-1 ${a.done ? "bg-slate-800/60 ring-emerald-500/30" : "bg-slate-900/40 opacity-60 ring-white/5"}`}>
            <div className="text-4xl grayscale-0" style={{ filter: a.done ? "none" : "grayscale(1)" }}>{a.icon}</div>
            <div className="flex-1"><p className="font-bold text-white">{a.name}</p><p className="text-xs text-slate-400">{a.desc}</p></div>
            {a.done ? <Badge color="bg-emerald-500/20 text-emerald-300">DONE</Badge> : <Badge color="bg-slate-700 text-slate-400">LOCKED</Badge>}
          </div>
        ))}
      </div>
    </PageShell>
  );
}
