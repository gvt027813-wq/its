import { useState } from "react";
import AdUnit, { type AdVariant } from "./AdUnit";
import { usePremium } from "../hooks/usePremium";
import { cn } from "../utils/cn";

/* ─────────────────────────────────────────────────────────────────
 * <InFeedAd />
 * Drops a banner between cards in a game grid.
 * Uses the leaderboard on desktop, banner on mobile.
 * ──────────────────────────────────────────────────────────────── */
export function InFeedAd({ className, slotId }: { className?: string; slotId?: string }) {
  return (
    <div
      className={cn(
        "col-span-3 flex items-center justify-center rounded-xl border border-white/5 bg-slate-900/30 p-3 sm:col-span-4 md:col-span-6 lg:col-span-7 xl:col-span-8",
        className
      )}
    >
      <div className="w-full">
        <div className="hidden md:block">
          <AdUnit variant="leaderboard" className="my-0" slotId={`${slotId || "in-feed"}-desktop`} />
        </div>
        <div className="block md:hidden">
          <AdUnit variant="banner" className="my-0" slotId={`${slotId || "in-feed"}-mobile`} />
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────
 * <SidebarAd />
 * Sticks inside the desktop sidebar, below the category list.
 * Hidden on mobile. Uses the 728×90 leaderboard scaled to fit 240px.
 * ──────────────────────────────────────────────────────────────── */
export function SidebarAd() {
  return (
    <div className="mx-3 mb-3 hidden lg:block">
      <p className="mb-1 text-center text-[10px] font-semibold uppercase tracking-[0.2em] text-slate-600">
        Sponsored
      </p>
      <div className="flex items-center justify-center overflow-hidden rounded-xl border border-amber-400/20 bg-gradient-to-br from-slate-900 to-slate-950 p-2">
        <div className="scale-[0.45] origin-center">
          <AdUnit variant="leaderboard" className="my-0" hideLabel responsive={false} slotId="sidebar" />
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────
 * <ArticleAd />
 * Inline ad for long-form content (blog posts, legal pages).
 * ──────────────────────────────────────────────────────────────── */
export function ArticleAd({ className, slotId }: { className?: string; slotId?: string }) {
  return <AdUnit variant="banner" className={cn("mx-auto", className)} slotId={slotId} />;
}

/* ─────────────────────────────────────────────────────────────────
 * <StickyAd />
 * Fixed-position ad on large screens only. Dismissable.
 * Used sparingly — only on high-value pages like Game Detail.
 * ──────────────────────────────────────────────────────────────── */
export function StickyAd() {
  const [dismissed, setDismissed] = useState(false);
  const { premium } = usePremium();
  if (dismissed || premium) return null;

  return (
    <div className="fixed bottom-20 left-1/2 z-30 hidden -translate-x-1/2 md:block">
      <div className="relative rounded-xl bg-slate-950/95 p-2 shadow-2xl ring-1 ring-amber-400/30 backdrop-blur">
        <button
          onClick={() => setDismissed(true)}
          className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-slate-800 text-xs text-white ring-1 ring-white/10 hover:bg-slate-700"
          aria-label="Close ad"
        >
          ✕
        </button>
        <AdUnit variant="leaderboard" className="my-0" hideLabel responsive={false} slotId="sticky-game" />
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────
 * <SponsoredBanner />
 * Native-looking promotional strip (different visual treatment).
 * Rotates through the two ad units so it never looks repetitive.
 * ──────────────────────────────────────────────────────────────── */
export function SponsoredBanner({ position = 0, className }: { position?: number; className?: string }) {
  const variant: AdVariant = position % 2 === 0 ? "banner" : "leaderboard";
  return (
    <div className={cn("rounded-2xl bg-gradient-to-r from-amber-500/10 via-slate-900/60 to-slate-900/60 p-4 ring-1 ring-amber-400/20", className)}>
      <div className="mb-2 flex items-center gap-2">
        <span className="rounded-md bg-amber-500/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-amber-300">
          Sponsored
        </span>
        <span className="text-[11px] text-slate-500">Partner offer · supports Play VAULT</span>
      </div>
      <div className="flex justify-center">
        <AdUnit variant={variant} className="my-0" hideLabel responsive slotId={`sponsored-${position}`} />
      </div>
    </div>
  );
}
