# 🎮 Play VAULT

**1000+ Free Online Games Hub — no downloads, instant play.**

- **Owner & Copyright Holder:** Vivek Trivedi
- **Contact:** vivektrivedi236@gmail.com
- **© 2026 Play VAULT. All rights reserved.**

---

## 🏗️ Architecture

| Layer | Tech |
|-------|------|
| Frontend | React 19 + Vite + TypeScript + Tailwind v4 + Framer Motion + React Router |
| Cloud DB | Firebase Auth + Realtime Database (`vplay-pro`) — secure user sync, public configuration, developer submission queue |
| Backend | Node.js + Express + MongoDB (Mongoose) — REST API in `backend/` |
| Game Source | GamePix public games API (1000+ HTML5 games) with curated fallback |
| SEO | Dynamic meta tags per page, Open Graph, Twitter cards, JSON-LD structured data, `sitemap.xml`, `robots.txt` |

## 🔥 Firebase Integration

Config lives in `src/services/firebase.ts` (project `vplay-pro`).

RTDB paths:

- `users/{uid}/favorites` — synced favorite game ids
- `users/{uid}/recent` — synced recently played ids
- `stats/plays/{uid}` — append-only authenticated play events
- `submissions/` — game submissions with auto/manual verification status
- `siteConfig/public` — read-only public website configuration, writable only by Firebase admins

## 🤖 Auto Game Add + Verify System

- The public game website contains **no admin route**.
- `admin-portal/` is deployed separately to `admin.playvault.gg` and requires Firebase email/password plus a server-assigned `admin: true` claim.
- `developer-portal/` is deployed separately to `developers.playvault.gg`; signed-in developers can submit games to the pending queue.
- Owner (Vivek Trivedi) can **Verify / Reject** from the secure admin queue and update public website links, hero buttons, ads, popup policy and branding live.
- Bulk pipeline: `backend/seed.js` auto-imports 1000+ GamePix games into MongoDB as verified.

## 🌐 REST API (backend/)

```bash
cd backend
npm install
npm run seed    # auto-add 1000+ verified games into MongoDB
npm start       # API on :5000
```

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Service health |
| GET | `/api/v1/games?category=&q=&limit=&page=` | Public list/filter/search, bounded pagination |
| POST | `/api/v1/games` | Firebase-authenticated game submission |
| PUT | `/api/v1/games/:id/verify` | Firebase-authenticated admin verification |

## 🔍 SEO Strategy

1. Keyword-optimized titles/descriptions per page (`src/components/SEO.tsx`)
2. BrowserRouter routes with Firebase Hosting SPA fallback and canonical sitemap URLs
3. JSON-LD `WebSite` + `Organization` (founder: Vivek Trivedi) schema
4. `robots.txt` allowing all crawlers + sitemap reference
5. Category landing pages (`/category/puzzle`, etc.) targeting long-tail keywords
6. Fast single-file bundle, lazy-loaded images, semantic HTML headings

## 🚀 Frontend Dev

```bash
npm install
npm run dev     # local dev
npm run build   # production build → dist/index.html (single file)
```

## 📄 Legal

Privacy, Terms, Cookies, DMCA, Disclaimer, Refund pages all in-app.
All legal/contact mail goes to **vivektrivedi236@gmail.com**.

## 🔐 Deployment

See [SECURITY_DEPLOYMENT.md](./SECURITY_DEPLOYMENT.md) for Firebase Auth setup, rules deployment, custom admin-claim assignment, secured API secrets, three-site Firebase Hosting deployment, and popup-ad policy.

See [SEO_IMPLEMENTATION.md](./SEO_IMPLEMENTATION.md) for the canonical URL structure, sitemap automation, Netlify redirects, custom-domain migration, and Search Console release checklist.
