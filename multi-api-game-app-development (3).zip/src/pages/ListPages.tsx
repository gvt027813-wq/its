import { useMemo, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { useGames } from "../store/GameContext";
import GameGrid from "../components/ui/GameGrid";
import PageShell from "../components/ui/PageShell";
import { SkeletonGrid, Loader } from "../components/ui/Common";
import AdUnit from "../components/AdUnit";
import SEO from "../components/SEO";
import { gamePath } from "../utils/gameUrl";

export function Trending() {
  const { games, loading } = useGames();
  const list = useMemo(() => [...games].sort((a, b) => (b.plays || 0) - (a.plays || 0)).slice(0, 120), [games]);
  return (
    <PageShell title="Trending Now" subtitle="The most played games right now" icon="🔥" maxWidth="max-w-none">
      <SEO title="Trending Free Online Games" description="Discover trending browser games on Play VAULT. Play action, puzzle, racing, arcade, and more with no download." path="/trending" />
      <AdUnit variant="leaderboard" slotId="trending-top" />
      {loading ? <SkeletonGrid /> : <GameGrid games={list} />}
    </PageShell>
  );
}

export function NewGames() {
  const { games, loading } = useGames();
  const list = useMemo(() => [...games].reverse().slice(0, 120), [games]);
  return (
    <PageShell title="New Games" subtitle="Freshly added to Play VAULT" icon="🆕" maxWidth="max-w-none">
      <SEO title="New Free Online Games" description="Explore newly added free browser games on Play VAULT. Play instantly with no download required." path="/new" />
      <AdUnit variant="leaderboard" slotId="new-games-top" />
      {loading ? <SkeletonGrid /> : <GameGrid games={list} />}
    </PageShell>
  );
}

export function TopRated() {
  const { games, loading } = useGames();
  const list = useMemo(() => [...games].sort((a, b) => (b.rating || 0) - (a.rating || 0)).slice(0, 120), [games]);
  return (
    <PageShell title="Top Rated" subtitle="Highest rated games by our community" icon="🏆" maxWidth="max-w-none">
      <SEO title="Top Rated Free Online Games" description="Browse top rated browser games across action, puzzle, racing, sports, and arcade categories." path="/top-rated" />
      <AdUnit variant="leaderboard" slotId="top-rated-top" />
      {loading ? <SkeletonGrid /> : <GameGrid games={list} />}
    </PageShell>
  );
}

export function Favorites() {
  const { games, favorites, loading } = useGames();
  const list = useMemo(() => games.filter((g) => favorites.includes(g.id)), [games, favorites]);
  return (
    <PageShell title="Your Favorites" subtitle={`${list.length} saved games`} icon="❤️" maxWidth="max-w-none">
      <SEO title="Your Favorite Games" description="Your saved Play VAULT games." path="/favorites" noIndex />
      <AdUnit variant="leaderboard" slotId="favorites-top" />
      {loading ? <SkeletonGrid /> : <GameGrid games={list} emptyText="Tap the heart on any game to save it here." />}
    </PageShell>
  );
}

export function Recent() {
  const { recent, getGame, loading } = useGames();
  const list = useMemo(() => recent.map(getGame).filter(Boolean) as ReturnType<typeof getGame>[], [recent, getGame]);
  return (
    <PageShell title="Recently Played" subtitle="Pick up where you left off" icon="🕒" maxWidth="max-w-none">
      <SEO title="Recently Played Games" description="Continue playing your recent Play VAULT games." path="/recent" noIndex />
      <AdUnit variant="leaderboard" slotId="recent-top" />
      {loading ? <SkeletonGrid /> : <GameGrid games={list as never} emptyText="You haven't played anything yet." />}
    </PageShell>
  );
}

export function SearchPage() {
  const [params] = useSearchParams();
  const q = params.get("q") || "";
  const { search, loading } = useGames();
  const list = useMemo(() => search(q), [search, q]);
  return (
    <PageShell title={`Search: "${q}"`} subtitle={`${list.length} results found`} icon="🔍" maxWidth="max-w-none">
      <SEO title={`Search Results for ${q}`} description={`Find free online games matching ${q} on Play VAULT.`} path={`/search?q=${encodeURIComponent(q)}`} noIndex />
      <AdUnit variant="leaderboard" slotId="search-top" />
      {loading ? <SkeletonGrid /> : <GameGrid games={list} emptyText={`No games found for "${q}". Try another keyword.`} />}
    </PageShell>
  );
}

export function RandomGame() {
  const { games, loading } = useGames();
  const navigate = useNavigate();
  useEffect(() => {
    if (!loading && games.length) {
      const g = games[Math.floor(Math.random() * games.length)];
      navigate(gamePath(g), { replace: true });
    }
  }, [loading, games, navigate]);
  return (
    <PageShell>
      <Loader label="Picking a random game for you…" />
    </PageShell>
  );
}
