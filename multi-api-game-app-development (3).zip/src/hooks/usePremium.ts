import { useCallback, useState } from "react";

const KEY = "playvault:premium";

export function usePremium() {
  const [premium, setPremium] = useState<boolean>(() => {
    try {
      return localStorage.getItem(KEY) === "1";
    } catch {
      return false;
    }
  });

  const activate = useCallback(() => {
    try {
      localStorage.setItem(KEY, "1");
    } catch {}
    setPremium(true);
  }, []);

  const deactivate = useCallback(() => {
    try {
      localStorage.removeItem(KEY);
    } catch {}
    setPremium(false);
  }, []);

  return { premium, activate, deactivate };
}
