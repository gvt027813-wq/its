const mongoose = require('mongoose');

const GameSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 120 }, description: { type: String, default: '', maxlength: 2000 }, category: { type: String, required: true, index: true },
  thumb: String, banner: String, url: { type: String, required: true }, source: { type: String, default: 'GamePix' }, submittedBy: String,
  featured: { type: Boolean, default: false }, rating: { type: Number, default: 4.2, min: 0, max: 5 },
  plays: { type: Number, default: 0, min: 0 }, playVaultPlays: { type: Number, default: 0, min: 0 }, width: Number, height: Number,
  verified: { type: Boolean, default: false, index: true }, verifiedAt: Date, verifiedBy: String,
}, { timestamps: true });

GameSchema.index({ title: 'text', description: 'text' }, { weights: { title: 10, description: 2 } });
GameSchema.index({ verified: 1, category: 1, plays: -1, createdAt: -1 });
module.exports = mongoose.model('Game', GameSchema);