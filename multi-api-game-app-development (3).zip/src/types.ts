export interface Game {
  id: string;
  title: string;
  description: string;
  category: string;
  thumb: string;
  banner?: string;
  url: string;
  source: string;
  width?: number;
  height?: number;
  featured?: boolean;
  rating?: number;
  plays?: number;
}

export interface CategoryInfo {
  id: string;
  name: string;
  icon: string;
  color: string;
}
