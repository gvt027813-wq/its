/**
 * Netlify dynamic prerendering for crawlers (SEO & Rich Results Engine).
 *
 * Serves fully rendered, crawlable HTML with title, meta tags, Open Graph,
 * JSON-LD schemas (VideoGame, FAQPage, CollectionPage, BreadcrumbList, WebSite),
 * H1/H2 headings, game guides, and internal category/game links.
 */

type GamePixGame = {
  id: string;
  title: string;
  description?: string;
  category?: string;
  categories?: string[];
  thumbnailUrl?: string;
  url?: string;
};

const BOT_PATTERN = /googlebot|bingbot|yandexbot|duckduckbot|baiduspider|facebookexternalhit|twitterbot|linkedinbot|slackbot|discordbot|whatsapp|ahrefsbot|semrushbot|dotbot|rogerbot|screaming frog|page speed|google-inspectiontool|chrome-lighthouse|mediapartners-google|adsbot-google|feedfetcher-google|bingpreview/i;
const SID = "98R78";
const FEED_URL = `https://games.gamepix.com/games?sid=${SID}&order=q&limit=1000`;
let catalog: Promise<GamePixGame[]> | null = null;

const CATEGORY_INFO: Record<string, { title: string; intro: string }> = {
  action: { title: "Action", intro: "Explore fast-paced action games with quick challenges, responsive controls, and instant browser play." },
  puzzle: { title: "Puzzle", intro: "Discover puzzle games that reward logic, pattern spotting, planning, and a little patience." },
  racing: { title: "Racing", intro: "Start a free racing game in your browser and take on tracks, time trials, stunts, and speed challenges." },
  sports: { title: "Sports", intro: "Play sports games online, from football and basketball to golf, pool, and skill-based challenges." },
  arcade: { title: "Arcade", intro: "Enjoy classic arcade-style games built for quick sessions, repeat runs, and high-score chases." },
  shooting: { title: "Shooting", intro: "Browse browser shooting games with skill-based missions, targets, and action challenges." },
  adventure: { title: "Adventure", intro: "Find adventure games with exploration, quests, stories, and new worlds to discover." },
  strategy: { title: "Strategy", intro: "Choose strategy games that reward thoughtful decisions, planning, and smart resource management." },
  board: { title: "Board", intro: "Play board and card-inspired games in your browser, including tactical favorites." },
  casual: { title: "Casual", intro: "Relax with casual browser games designed for quick, easy-to-start sessions." },
  io: { title: ".io", intro: "Jump into multiplayer-inspired .io games with quick matches and competitive browser gameplay." },
  girls: { title: "Girls", intro: "Explore creative dress-up, fashion, beauty, and casual browser games." },
};

function escapeHtml(value = "") {
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function slugify(value = "") {
  return String(value).toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "game";
}

function normalizeCategory(raw = "") {
  const c = String(raw).toLowerCase();
  if (/action|fight|war|battle/.test(c)) return "action";
  if (/puzzle|match|brain|logic|blocks/.test(c)) return "puzzle";
  if (/rac|car|drive|drift|bike|moto/.test(c)) return "racing";
  if (/sport|soccer|football|basket|golf|pool/.test(c)) return "sports";
  if (/arcade|classic|retro/.test(c)) return "arcade";
  if (/shoot|gun|sniper|zombie/.test(c)) return "shooting";
  if (/adventure|rpg|quest|escape/.test(c)) return "adventure";
  if (/girl|dress|makeup|fashion|beauty/.test(c)) return "girls";
  if (/strategy|tower|defense|manage/.test(c)) return "strategy";
  if (/board|card|chess|checker|domino/.test(c)) return "board";
  if (/io|multiplayer/.test(c)) return "io";
  return "casual";
}

async function loadCatalog() {
  if (!catalog) {
    catalog = fetch(FEED_URL, { headers: { Accept: "application/json" } })
      .then((response) => response.ok ? response.json() : { data: [] })
      .then((payload) => Array.isArray(payload.data) ? payload.data : [])
      .catch(() => []);
  }
  return catalog;
}

function layout(origin: string, title: string, description: string, canonicalPath: string, image: string, body: string, schema: unknown) {
  const canonical = `${origin}${canonicalPath}`;
  const imageUrl = image || `${origin}/images/hero.jpg`;
  const defaultKeywords = "VaultPlays, Play VAULT, Vault Play, Play Vault, VaultPlay, Vault Games, free online games, browser games, free games no download, HTML5 games, action games, racing games, puzzle games, arcade games";

  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHtml(title)} | VaultPlays (Play VAULT)</title><meta name="description" content="${escapeHtml(description)}">
<meta name="keywords" content="${defaultKeywords}">
<meta name="author" content="Vivek Trivedi">
<link rel="canonical" href="${escapeHtml(canonical)}"><meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1">
<meta property="og:type" content="website"><meta property="og:title" content="${escapeHtml(title)}"><meta property="og:description" content="${escapeHtml(description)}"><meta property="og:url" content="${escapeHtml(canonical)}"><meta property="og:site_name" content="VaultPlays / Play VAULT"><meta property="og:image" content="${escapeHtml(imageUrl)}">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${escapeHtml(title)}"><meta name="twitter:description" content="${escapeHtml(description)}"><meta name="twitter:image" content="${escapeHtml(imageUrl)}">
<script type="application/ld+json">${JSON.stringify(schema).replace(/</g, "\\u003c")}</script>
<style>body{margin:0;background:#020617;color:#e2e8f0;font:16px/1.6 system-ui,sans-serif}main{max-width:960px;margin:auto;padding:32px 20px}a{color:#fbbf24;text-decoration:none}nav{font-size:14px;color:#94a3b8;margin-bottom:24px}.hero{display:grid;grid-template-columns:190px 1fr;gap:24px;padding:24px;border:1px solid #334155;border-radius:18px;background:#0f172a}.hero img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:12px}h1{line-height:1.15;margin:0 0 10px;color:#fff}h2{color:#fff;margin-top:30px}.button{display:inline-block;margin-top:14px;padding:10px 16px;border-radius:10px;background:#b26f1b;color:#fff;font-weight:700}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}.card{border:1px solid #334155;border-radius:10px;padding:12px;background:#111c30}.card img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px}@media(max-width:600px){.hero{grid-template-columns:1fr}.hero img{max-width:200px}}</style>
</head><body><main>${body}</main></body></html>`;
}

function homeMarkup(origin: string, games: GamePixGame[]) {
  const cards = games.slice(0, 32).map((game) => {
    const id = `gp-${String(game.id).toLowerCase()}`;
    const category = normalizeCategory(game.category || game.categories?.[0]);
    const path = `/games/${category}/${slugify(game.title)}--${encodeURIComponent(id)}`;
    return `<article class="card"><a href="${path}"><img src="${escapeHtml(game.thumbnailUrl || `${origin}/images/hero.jpg`)}" alt="Play ${escapeHtml(game.title)} online on VaultPlays"><strong>${escapeHtml(game.title)}</strong></a></article>`;
  }).join("");

  const schema = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebSite",
        name: "VaultPlays",
        alternateName: ["Play VAULT", "Vault Play", "Play Vault", "VaultPlay", "Vault Games"],
        url: origin,
        description: "Play free online games instantly on VaultPlays (Play VAULT). Discover 1000+ action, arcade, puzzle, racing and casual games with no download required.",
        publisher: {
          "@type": "Organization",
          name: "VaultPlays / Play VAULT",
          founder: { "@type": "Person", name: "Vivek Trivedi" },
          logo: `${origin}/images/logo.png`
        },
        potentialAction: {
          "@type": "SearchAction",
          target: `${origin}/search?q={search_term_string}`,
          "query-input": "required name=search_term_string",
        }
      }
    ]
  };

  const body = `<h1>Play Free Online Games on VaultPlays (Play VAULT)</h1>
  <p>Welcome to <strong>VaultPlays</strong> (also known as <strong>Play VAULT</strong>, <strong>Vault Play</strong>, or <strong>Play Vault</strong>). Play 1000+ free online games instantly in your web browser with zero download required. Discover the best action games, car racing games, logic puzzle games, shooting games, sports games, and multiplayer .io games.</p>
  <nav aria-label="Game Categories">
    <a href="/games">All Games</a> |
    <a href="/games/action">Action Games</a> |
    <a href="/games/puzzle">Puzzle Games</a> |
    <a href="/games/racing">Racing Games</a> |
    <a href="/games/sports">Sports Games</a> |
    <a href="/games/arcade">Arcade Games</a> |
    <a href="/games/shooting">Shooting Games</a> |
    <a href="/games/adventure">Adventure Games</a> |
    <a href="/games/casual">Casual Games</a>
  </nav>
  <h2>Featured Free Browser Games on VaultPlays</h2>
  <section class="grid">${cards}</section>`;

  return layout(origin, "Free Online Games - Play 1000+ Games", "Play free online games instantly on VaultPlays (Play VAULT). Discover 1000+ action, arcade, puzzle, racing and casual games with no download required.", "/", `${origin}/images/hero.jpg`, body, schema);
}

function gameMarkup(origin: string, game: GamePixGame, category: string, canonicalPath: string) {
  const description = game.description || `Play ${game.title} free online in your browser on VaultPlays (Play VAULT) with no download required.`;
  const categoryName = CATEGORY_INFO[category]?.title || category;
  const image = game.thumbnailUrl || `${origin}/images/hero.jpg`;
  const schema = {
    "@context": "https://schema.org",
    "@graph": [
      { "@type": "VideoGame", name: game.title, description, url: `${origin}${canonicalPath}`, image, genre: categoryName, gamePlatform: "Web browser", applicationCategory: "Game", operatingSystem: "Any", isAccessibleForFree: true, offers: { "@type": "Offer", price: "0", priceCurrency: "USD" } },
      { "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "Home", item: origin }, { "@type": "ListItem", position: 2, name: `${categoryName} Games`, item: `${origin}/games/${category}` }, { "@type": "ListItem", position: 3, name: game.title, item: `${origin}${canonicalPath}` }] },
      { "@type": "FAQPage", mainEntity: [
        { "@type": "Question", name: `Is ${game.title} free to play on VaultPlays?`, acceptedAnswer: { "@type": "Answer", text: `Yes. ${game.title} is completely free to play in any compatible web browser on VaultPlays (Play VAULT).` } },
        { "@type": "Question", name: `Do I need to download ${game.title}?`, acceptedAnswer: { "@type": "Answer", text: "No download or installation is required. Start playing directly in your browser." } },
      ] },
    ],
  };
  const body = `<nav><a href="/">Home</a> / <a href="/games">Games</a> / <a href="/games/${category}">${escapeHtml(categoryName)} Games</a> / ${escapeHtml(game.title)}</nav>
  <article><section class="hero"><img src="${escapeHtml(image)}" alt="Play ${escapeHtml(game.title)} online on VaultPlays"><div><h1>Play ${escapeHtml(game.title)} Free Online on VaultPlays</h1><p>${escapeHtml(description)}</p><a class="button" href="${escapeHtml(canonicalPath)}">Play ${escapeHtml(game.title)} Now</a></div></section>
  <h2>About ${escapeHtml(game.title)}</h2><p>${escapeHtml(description)} Play instantly on VaultPlays (Play VAULT) with zero download required.</p>
  <h2>How to Play ${escapeHtml(game.title)}</h2><p>Select Play to start. Most browser games support mouse, keyboard, or touch controls depending on your device.</p>
  <h2>Quick Gameplay Tips</h2><ul><li>Learn the control layout during your first practice session.</li><li>Try repeated runs to improve your score and master mechanics.</li></ul>
  <h2>${escapeHtml(game.title)} FAQ</h2><p><strong>Is it free?</strong> Yes, play online for free on VaultPlays.</p><p><strong>Do I need a download?</strong> No download or install is required.</p>
  <p><a href="/games/${category}">Browse more free ${escapeHtml(categoryName.toLowerCase())} games</a> or <a href="/games">view all online games</a> on VaultPlays.</p></article>`;
  return layout(origin, `Play ${game.title} Free Online`, description, canonicalPath, image, body, schema);
}

function categoryMarkup(origin: string, category: string, games: GamePixGame[]) {
  const info = CATEGORY_INFO[category] || { title: "Casual", intro: "Browse free browser games and play instantly." };
  const cards = games.slice(0, 32).map((game) => {
    const id = `gp-${String(game.id).toLowerCase()}`;
    const path = `/games/${category}/${slugify(game.title)}--${encodeURIComponent(id)}`;
    return `<article class="card"><a href="${path}"><img src="${escapeHtml(game.thumbnailUrl || `${origin}/images/hero.jpg`)}" alt="Play ${escapeHtml(game.title)} online on VaultPlays"><strong>${escapeHtml(game.title)}</strong></a></article>`;
  }).join("");
  const description = `${info.intro} Play free ${info.title.toLowerCase()} games online with no download required on VaultPlays (Play VAULT).`;
  const schema = { "@context": "https://schema.org", "@type": "CollectionPage", name: `Free ${info.title} Games`, description, url: `${origin}/games/${category}`, numberOfItems: games.length };
  return layout(origin, `Free ${info.title} Games Online`, description, `/games/${category}`, `${origin}/images/hero.jpg`, `<nav><a href="/">Home</a> / <a href="/games">Games</a> / ${escapeHtml(info.title)} Games</nav><h1>Free ${escapeHtml(info.title)} Games on VaultPlays</h1><p>${escapeHtml(description)}</p><section class="grid">${cards || "<p>New games are being added to this category.</p>"}</section>`, schema);
}

export default async (request: Request, context: { next: () => Promise<Response> }) => {
  const userAgent = request.headers.get("user-agent") || "";
  if (!BOT_PATTERN.test(userAgent)) return context.next();

  const url = new URL(request.url);
  const path = url.pathname;

  const entries = await loadCatalog();

  // Serve prerendered HTML for homepage
  if (path === "/" || path === "") {
    return new Response(homeMarkup(url.origin, entries), { headers: { "content-type": "text/html; charset=UTF-8", "cache-control": "public, max-age=300" } });
  }

  const parts = path.split("/").filter(Boolean);

  // /games or /category
  if (parts[0] === "games" || parts[0] === "category") {
    if (parts.length === 1) {
      return new Response(homeMarkup(url.origin, entries), { headers: { "content-type": "text/html; charset=UTF-8", "cache-control": "public, max-age=300" } });
    }
    if (parts.length === 2) {
      const category = parts[1];
      const games = entries.filter((game) => normalizeCategory(game.category || game.categories?.[0]) === category);
      return new Response(categoryMarkup(url.origin, category, games), { headers: { "content-type": "text/html; charset=UTF-8", "cache-control": "public, max-age=300" } });
    }
    if (parts.length >= 3) {
      const slug = decodeURIComponent(parts.slice(2).join("/"));
      const idMatch = slug.match(/--gp-([a-z0-9]+)$/i);
      const game = idMatch ? entries.find((entry) => String(entry.id).toLowerCase() === idMatch[1].toLowerCase()) : undefined;
      if (!game) return context.next();
      const category = normalizeCategory(game.category || game.categories?.[0]);
      const canonicalPath = `/games/${category}/${slugify(game.title)}--${encodeURIComponent(`gp-${String(game.id).toLowerCase()}`)}`;
      return new Response(gameMarkup(url.origin, game, category, canonicalPath), { headers: { "content-type": "text/html; charset=UTF-8", "cache-control": "public, max-age=300" } });
    }
  }

  // /game/:id legacy route handling
  if (parts[0] === "game" && parts.length === 2) {
    const rawId = parts[1].toLowerCase().replace(/^gp-/, "");
    const game = entries.find((entry) => String(entry.id).toLowerCase() === rawId);
    if (!game) return context.next();
    const category = normalizeCategory(game.category || game.categories?.[0]);
    const canonicalPath = `/games/${category}/${slugify(game.title)}--${encodeURIComponent(`gp-${String(game.id).toLowerCase()}`)}`;
    return new Response(gameMarkup(url.origin, game, category, canonicalPath), { headers: { "content-type": "text/html; charset=UTF-8", "cache-control": "public, max-age=300" } });
  }

  return context.next();
};

export const config = { path: "/*" };
